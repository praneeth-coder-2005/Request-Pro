<?php
/**
 * Template part for displaying player.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Muvipro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php
	$notification = get_post_meta( $post->ID, 'IDMUVICORE_Notif', true );

	$player1      = get_post_meta( $post->ID, 'IDMUVICORE_Player1', true );
	$titleplayer1 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player1', true );

	$player2      = get_post_meta( $post->ID, 'IDMUVICORE_Player2', true );
	$titleplayer2 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player2', true );

	$player3      = get_post_meta( $post->ID, 'IDMUVICORE_Player3', true );
	$titleplayer3 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player3', true );

	$player4      = get_post_meta( $post->ID, 'IDMUVICORE_Player4', true );
	$titleplayer4 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player4', true );

	$player5      = get_post_meta( $post->ID, 'IDMUVICORE_Player5', true );
	$titleplayer5 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player5', true );

	$player6      = get_post_meta( $post->ID, 'IDMUVICORE_Player6', true );
	$titleplayer6 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player6', true );

	$player7      = get_post_meta( $post->ID, 'IDMUVICORE_Player7', true );
	$titleplayer7 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player7', true );

	$player8      = get_post_meta( $post->ID, 'IDMUVICORE_Player8', true );
	$titleplayer8 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player8', true );

	$player9      = get_post_meta( $post->ID, 'IDMUVICORE_Player9', true );
	$titleplayer9 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player9', true );

	$player10      = get_post_meta( $post->ID, 'IDMUVICORE_Player10', true );
	$titleplayer10 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player10', true );

	$player11      = get_post_meta( $post->ID, 'IDMUVICORE_Player11', true );
	$titleplayer11 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player11', true );

	$player12      = get_post_meta( $post->ID, 'IDMUVICORE_Player12', true );
	$titleplayer12 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player12', true );

	$player13      = get_post_meta( $post->ID, 'IDMUVICORE_Player13', true );
	$titleplayer13 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player13', true );

	$player14      = get_post_meta( $post->ID, 'IDMUVICORE_Player14', true );
	$titleplayer14 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player14', true );

	$player15      = get_post_meta( $post->ID, 'IDMUVICORE_Player15', true );
	$titleplayer15 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Player15', true );

	$trailer = get_post_meta( $post->ID, 'IDMUVICORE_Trailer', true );

	$download1 = get_post_meta( $post->ID, 'IDMUVICORE_Download1', true );

if ( ! empty( $player1 )
|| ! empty( $player2 )
|| ! empty( $player3 )
|| ! empty( $player4 )
|| ! empty( $player5 )
|| ! empty( $player6 )
|| ! empty( $player7 )
|| ! empty( $player8 )
|| ! empty( $player9 )
|| ! empty( $player10 )
|| ! empty( $player11 )
|| ! empty( $player12 )
|| ! empty( $player13 )
|| ! empty( $player14 )
|| ! empty( $player15 )
) {

	do_action( 'idmuvi_core_top_player' ); // Banner before player.

	$globalnotification = get_theme_mod( 'gmr_notifplayer' );

	if ( ! empty( $globalnotification ) ) {
		?>
		<div class="gmr-notification player-notification global-notification">
			<div class="marquee">
				<?php echo esc_html( $globalnotification ); ?>
			</div>
		</div>
	<?php } ?>

	<?php
	if ( ! empty( $notification ) ) {
		?>
		<div class="gmr-notification player-notification">
			<div class="marquee">
				<?php echo esc_html( $notification ); ?>
			</div>
		</div>
	<?php } ?>

	<div class="gmr-server-wrap clearfix muvipro_player_content" id="muvipro_player_content_id" data-id="<?php echo esc_html( $post->ID ); ?>">
		<div class="clearfix">
			<?php if ( ! empty( $player1 ) ) { ?>
				<div id="player1-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player2 ) ) { ?>
				<div id="player2-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player3 ) ) { ?>
				<div id="player3-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player4 ) ) { ?>
				<div id="player4-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player5 ) ) { ?>
				<div id="player5-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player6 ) ) { ?>
				<div id="player6-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player7 ) ) { ?>
				<div id="player7-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player8 ) ) { ?>
				<div id="player8-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player9 ) ) { ?>
				<div id="player9-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player10 ) ) { ?>
				<div id="player10-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player11 ) ) { ?>
				<div id="player11-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player12 ) ) { ?>
				<div id="player12-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player13 ) ) { ?>
				<div id="player13-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player14 ) ) { ?>
				<div id="player14-tab-content" class="tab-content">
				</div>
			<?php } ?>
			<?php if ( ! empty( $player15 ) ) { ?>
				<div id="player15-tab-content" class="tab-content">
				</div>
			<?php } ?>
		</div>

		<ul class="gmr-player-nav clearfix">
			<li><a href="javascript:void(0)" class="gmr-switch-button" title="<?php echo esc_html_e( 'Turn off light', 'muvipro' ); ?>" rel="nofollow"><span class="icon_lightbulb" aria-hidden="true"></span>  <span class="text"><?php echo esc_html_e( 'Turn off light', 'muvipro' ); ?></span></a></li>
			<li><a href="#comments" title="<?php echo esc_html_e( 'Comments', 'muvipro' ); ?>" rel="nofollow"><span class="icon_chat_alt" aria-hidden="true"></span>  <span class="text"><?php echo esc_html_e( 'Comments', 'muvipro' ); ?></span></a></li>
			<?php
			if ( ! empty( $trailer ) ) {
				echo '<li>';
				echo '<a href="https://www.youtube.com/watch?v=' . esc_html( $trailer ) . '" class="gmr-trailer-popup" title="';
				the_title_attribute(
					array(
						'before' => __( 'Trailer for ', 'muvipro' ),
						'after'  => '',
						'echo'   => true,
					)
				);
				echo '" rel="nofollow"><span class="icon_film" aria-hidden="true"></span>  <span class="text">' . esc_html__( 'Trailer', 'muvipro' ) . '</span></a>';
				echo '</li>';
			}
			if ( ! empty( $download1 ) ) {
				?>
				<li class="pull-right"><a class="popup-download" href="#download" title="<?php echo esc_html__( 'Download', 'muvipro' ); ?>" rel="nofollow"><span class="icon_download" aria-hidden="true"></span>  <span class="textdownload"><?php echo esc_html_e( 'Download', 'muvipro' ); ?></span></a></li>
			<?php } ?>
		</ul>

		<ul class="muvipro-player-tabs nav nav-tabs clearfix" id="gmr-tab">
			<?php
			if ( ! empty( $player1 ) ) {
				echo '<li><a href="#" id="player1" rel="nofollow">';
				if ( ! empty( $titleplayer1 ) ) {
					echo esc_html( $titleplayer1 );
				} else {
					echo esc_html__( 'Server 1', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player2 ) ) {
				echo '<li><a href="#" id="player2" rel="nofollow">';
				if ( ! empty( $titleplayer2 ) ) {
					echo esc_html( $titleplayer2 );
				} else {
					echo esc_html__( 'Server 2', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player3 ) ) {
				echo '<li><a href="#" id="player3" rel="nofollow">';
				if ( ! empty( $titleplayer3 ) ) {
					echo esc_html( $titleplayer3 );
				} else {
					echo esc_html__( 'Server 3', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player4 ) ) {
				echo '<li><a href="#" id="player4" rel="nofollow">';
				if ( ! empty( $titleplayer4 ) ) {
					echo esc_html( $titleplayer4 );
				} else {
					echo esc_html__( 'Server 4', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player5 ) ) {
				echo '<li><a href="#" id="player5" rel="nofollow">';
				if ( ! empty( $titleplayer5 ) ) {
					echo esc_html( $titleplayer5 );
				} else {
					echo esc_html__( 'Server 5', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player6 ) ) {
				echo '<li><a href="#" id="player6" rel="nofollow">';
				if ( ! empty( $titleplayer6 ) ) {
					echo esc_html( $titleplayer6 );
				} else {
					echo esc_html__( 'Server 6', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player7 ) ) {
				echo '<li><a href="#" id="player7" rel="nofollow">';
				if ( ! empty( $titleplayer7 ) ) {
					echo esc_html( $titleplayer7 );
				} else {
					echo esc_html__( 'Server 7', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player8 ) ) {
				echo '<li><a href="#" id="player8" rel="nofollow">';
				if ( ! empty( $titleplayer8 ) ) {
					echo esc_html( $titleplayer8 );
				} else {
					echo esc_html__( 'Server 8', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player9 ) ) {
				echo '<li><a href="#" id="player9" rel="nofollow">';
				if ( ! empty( $titleplayer9 ) ) {
					echo esc_html( $titleplayer9 );
				} else {
					echo esc_html__( 'Server 9', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player10 ) ) {
				echo '<li><a href="#" id="player10" rel="nofollow">';
				if ( ! empty( $titleplayer10 ) ) {
					echo esc_html( $titleplayer10 );
				} else {
					echo esc_html__( 'Server 10', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player11 ) ) {
				echo '<li><a href="#" id="player11" rel="nofollow">';
				if ( ! empty( $titleplayer11 ) ) {
					echo esc_html( $titleplayer11 );
				} else {
					echo esc_html__( 'Server 11', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player12 ) ) {
				echo '<li><a href="#" id="player12" rel="nofollow">';
				if ( ! empty( $titleplayer12 ) ) {
					echo esc_html( $titleplayer12 );
				} else {
					echo esc_html__( 'Server 12', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player13 ) ) {
				echo '<li><a href="#" id="player13" rel="nofollow">';
				if ( ! empty( $titleplayer13 ) ) {
					echo esc_html( $titleplayer13 );
				} else {
					echo esc_html__( 'Server 13', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player14 ) ) {
				echo '<li><a href="#" id="player14" rel="nofollow">';
				if ( ! empty( $titleplayer14 ) ) {
					echo esc_html( $titleplayer14 );
				} else {
					echo esc_html__( 'Server 14', 'muvipro' );
				}
				echo '</a></li>';
			}
			if ( ! empty( $player15 ) ) {
				echo '<li><a href="#" id="player15" rel="nofollow">';
				if ( ! empty( $titleplayer15 ) ) {
					echo esc_html( $titleplayer15 );
				} else {
					echo esc_html__( 'Server 15', 'muvipro' );
				}
				echo '</a></li>';
			}
			?>
		</ul>
	</div>

	<?php do_action( 'idmuvi_core_after_player' ); // Banner after player. ?>

	<div id="lightoff"></div>

<?php } else { ?>

	<?php
	// Display content if have no embed code via player metaboxes.
	$noembed_setting = get_theme_mod( 'gmr_player_appear', 'trailer' );
	if ( ! empty( $trailer ) && 'trailer' === $noembed_setting ) {
		?>

		<?php do_action( 'idmuvi_core_top_player' ); // Banner before player. ?>

		<div class="gmr-server-wrap clearfix">
			<div class="tab-content">
				<?php do_action( 'idmuvi_core_banner_player' ); ?>
				<div class="gmr-embed-responsive">
					<iframe src="https://www.youtube.com/embed/<?php echo esc_html( $trailer ); ?>" frameborder="0" allowfullscreen></iframe>
				</div>
			</div>

			<ul class="gmr-player-nav clearfix">
				<li><a href="javascript:void(0)" class="gmr-switch-button" title="<?php echo esc_html_e( 'Turn off light', 'muvipro' ); ?>" rel="nofollow"><span class="icon_lightbulb" aria-hidden="true"></span>  <span class="text"><?php echo esc_html_e( 'Turn off light', 'muvipro' ); ?></span></a></li>
				<li><a href="#comments" title="<?php echo esc_html_e( 'Comments', 'muvipro' ); ?>" rel="nofollow"><span class="icon_chat_alt" aria-hidden="true"></span>  <span class="text"><?php echo esc_html_e( 'Comments', 'muvipro' ); ?></span></a></li>
				<?php if ( ! empty( $download1 ) ) { ?>
					<li class="pull-right"><a class="popup-download" href="#download" title="<?php echo esc_html__( 'Download', 'muvipro' ); ?>" rel="nofollow"><span class="icon_download" aria-hidden="true"></span>  <span class="textdownload"><?php echo esc_html_e( 'Download', 'muvipro' ); ?></span></a></li>
				<?php } ?>
			</ul>
		</div>

		<?php do_action( 'idmuvi_core_after_player' ); // Banner after player. ?>

		<div id="lightoff"></div>

	<?php } elseif ( 'text' === $noembed_setting ) { ?>
		<?php
		if ( ! is_singular( 'tv' ) ) {
			$textcommingsoon = get_theme_mod( 'gmr_textplayer' );
			?>
			<div class="gmr-server-wrap clearfix">
				<div class="gmr-embed-text">
					<?php
					if ( $textcommingsoon ) {
						// sanitize html output than convert it again using htmlspecialchars_decode.
						echo esc_html( $textcommingsoon );

					} else {
						echo esc_html__( 'Comming Soon', 'muvipro' );

					}
					?>
				</div>
			</div>
		<?php } ?>
	<?php } ?>
<?php } ?>
