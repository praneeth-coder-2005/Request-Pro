<?php
/**
 * FB comments template file.
 * This replaces the theme's comment template when fb comments are enable
 *
 * @package muvipro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// option, section, default.
$appid = get_theme_mod( 'gmr_fbappid', '1703072823350490' );
?>
<div class="gmr-fbcomment">
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0];
	if (d.getElementById(id)) return;
	js = d.createElement(s); js.id = id;
	js.src = "//connect.facebook.net/<?php bloginfo( 'language' ); ?>/sdk.js#xfbml=1&appId=<?php echo esc_html( $appid ); ?>&version=v3.1&autoLogAppEvents=1";
	fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
	<div id="comments" class="gmr-fb-comments">
		<div class="fb-comments" data-href="<?php the_permalink(); ?>" data-numposts="5" data-width="100%"></div>
	</div>
</div>
