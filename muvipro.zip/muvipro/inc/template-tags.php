<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Muvipro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gmr_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_posted_on() {
		$time_string = '<time class="entry-date published updated" ' . muvipro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" ' . muvipro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = esc_html__( 'Posted on ', 'muvipro' ) . $time_string;

		$posted_by = esc_html__( 'By ', 'muvipro' ) . '<span class="entry-author vcard" ' . muvipro_itemprop_schema( 'author' ) . ' ' . muvipro_itemtype_schema( 'person' ) . '><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . __( 'Permalink to: ', 'muvipro' ) . esc_html( get_the_author() ) . '" ' . muvipro_itemprop_schema( 'url' ) . '><span ' . muvipro_itemprop_schema( 'name' ) . '>' . esc_html( get_the_author() ) . '</span></a></span>';
		if ( is_single() ) :
			echo '<span class="byline"> ' . $posted_by . '</span><span class="posted-on">' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		else :
			echo '<div class="gmr-metacontent"><span class="byline"> ' . $posted_by . '</span><span class="posted-on">' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		endif;
	}
endif; // endif gmr_posted_on.

if ( ! function_exists( 'gmr_movie_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_movie_on() {
		global $post;
		echo '<div class="gmr-movie-on">';
		$categories_list = get_the_category_list( esc_html__( ', ', 'muvipro' ) );
		if ( $categories_list ) {
			echo $categories_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo ', ';
		}
		if ( ! is_wp_error( get_the_term_list( $post->ID, 'muvicountry' ) ) ) {
			$termlist = get_the_term_list( $post->ID, 'muvicountry' );
			if ( ! empty( $termlist ) ) {
				echo get_the_term_list( $post->ID, 'muvicountry', '<span itemprop="contentLocation" itemscope="itemscope" itemtype="http://schema.org/Place">', '</span>, <span itemprop="contentLocation" itemscope="itemscope" itemtype="http://schema.org/Place">', '</span>' );
			}
		}
		echo '</div>';
	}
endif; // endif gmr_movie_on.

if ( ! function_exists( 'gmr_moviemeta_after_content' ) ) :
	/**
	 * Prints HTML with meta information for the cast and other movie meta
	 *
	 * @param string $content Content.
	 * @since 1.0.0
	 *
	 * @return string
	 */
	function gmr_moviemeta_after_content( $content ) {
		global $post;

		if ( is_singular( array( 'post', 'tv', 'episode' ) ) && in_the_loop() ) {

			$content .= '<div class="clearfix content-moviedata">';

			$tagline = get_post_meta( $post->ID, 'IDMUVICORE_Tagline', true );
			if ( ! empty( $tagline ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Tagline:', 'muvipro' ) . '</strong>';
				$content .= $tagline . '</div>';
			}

			$seriename = get_post_meta( $post->ID, 'IDMUVICORE_Title_Episode', true );
			if ( ! empty( $seriename ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Episode Name:', 'muvipro' ) . '</strong>';
				$content .= $seriename . '</div>';
			}

			if ( ! is_wp_error( get_the_term_list( $post->ID, 'muvicountry' ) ) ) {
				$termlist = get_the_term_list( $post->ID, 'muvicountry' );
				if ( ! empty( $termlist ) ) {
					$content .= '<div class="gmr-moviedata"><strong>' . __( 'Country:', 'muvipro' ) . '</strong>';
					$content .= get_the_term_list( $post->ID, 'muvicountry', '<span itemprop="contentLocation" itemscope="itemscope" itemtype="http://schema.org/Place">', '</span>, <span itemprop="contentLocation" itemscope="itemscope" itemtype="http://schema.org/Place">', '</span></div>' );
				}
			}

			$release = get_post_meta( $post->ID, 'IDMUVICORE_Released', true );
			// Check if the custom field has a value.
			if ( ! empty( $release ) ) {
				if ( true === gmr_checkIsAValidDate( $release ) ) {
					$datetime = new DateTime( $release );
					$content .= '<div class="gmr-moviedata"><strong>' . __( 'Release:', 'muvipro' ) . '</strong>';
					$content .= '<span><time itemprop="dateCreated" datetime="' . $datetime->format( 'c' ) . '">' . $release . '</time></span></div>';
				}
			}

			$airdate = get_post_meta( $post->ID, 'IDMUVICORE_Lastdate', true );
			// Check if the custom field has a value.
			if ( ! empty( $airdate ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Last Air Date:', 'muvipro' ) . '</strong>';
				$content .= $airdate . '</div>';
			}

			$episodes = get_post_meta( $post->ID, 'IDMUVICORE_Numbepisode', true );
			// Check if the custom field has a value.
			if ( ! empty( $episodes ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Number Of Episode:', 'muvipro' ) . '</strong>';
				$content .= $episodes . '</div>';
			}

			if ( ! is_wp_error( get_the_term_list( $post->ID, 'muvinetwork' ) ) ) {
				$termlist = get_the_term_list( $post->ID, 'muvinetwork' );
				if ( ! empty( $termlist ) ) {
					$content .= '<div class="gmr-moviedata"><strong>' . __( 'Network:', 'muvipro' ) . '</strong>';
					$content .= get_the_term_list( $post->ID, 'muvinetwork', '<span>', '</span>, <span>', '</span></div>' );
				}
			}

			$language = get_post_meta( $post->ID, 'IDMUVICORE_Language', true );
			// Check if the custom field has a value.
			if ( ! empty( $language ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Language:', 'muvipro' ) . '</strong>';
				$content .= '<span property="inLanguage">';
				$content .= $language;
				$content .= '</span>';
				$content .= '</div>';
			}

			$translator = get_post_meta( $post->ID, 'IDMUVICORE_Translate', true );
			// Check if the custom field has a value.
			if ( ! empty( $translator ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Translator:', 'muvipro' ) . '</strong>';
				$content .= $translator;
				$content .= '</div>';
			}

			$budget = get_post_meta( $post->ID, 'IDMUVICORE_Budget', true );
			// Check if the custom field has a value.
			if ( ! empty( $budget ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Budget:', 'muvipro' ) . '</strong>';
				$content .= '$ ' . number_format( (float) $budget, 2, ',', '.' );
				$content .= '</div>';
			}

			$revenue = get_post_meta( $post->ID, 'IDMUVICORE_Revenue', true );
			// Check if the custom field has a value.
			if ( ! empty( $revenue ) ) {
				$content .= '<div class="gmr-moviedata"><strong>' . __( 'Revenue:', 'muvipro' ) . '</strong>';
				$content .= '$ ' . number_format( (float) $revenue, 2, ',', '.' );
				$content .= '</div>';
			}

			if ( ! is_wp_error( get_the_term_list( $post->ID, 'muvidirector' ) ) ) {
				$termlist = get_the_term_list( $post->ID, 'muvidirector' );
				if ( ! empty( $termlist ) ) {
					$content .= '<div class="gmr-moviedata"><strong>' . __( 'Director:', 'muvipro' ) . '</strong>';
					$content .= get_the_term_list( $post->ID, 'muvidirector', '<span itemprop="director" itemscope="itemscope" itemtype="http://schema.org/Person"><span itemprop="name">', '</span></span>, <span itemprop="director" itemscope="itemscope" itemtype="http://schema.org/Person"><span itemprop="name">', '</span></span></div>' );
				}
			}

			if ( ! is_wp_error( get_the_term_list( $post->ID, 'muvicast' ) ) ) {
				$termlist = get_the_term_list( $post->ID, 'muvicast' );
				if ( ! empty( $termlist ) ) {
					$content .= '<div class="gmr-moviedata"><strong>' . __( 'Cast:', 'muvipro' ) . '</strong>';
					$content .= get_the_term_list( $post->ID, 'muvicast', '<span itemprop="actors" itemscope="itemscope" itemtype="http://schema.org/Person"><span itemprop="name">', '</span></span>, <span itemprop="actors" itemscope="itemscope" itemtype="http://schema.org/Person"><span itemprop="name">', '</span></span></div>' );
				}
			}

			$content .= '</div>';
			$content .= '<br/>'; // add br for prevent paragraph error.

			return $content;
		}
		return $content;
	}
endif;
add_filter( 'the_content', 'gmr_moviemeta_after_content', 3 );

if ( ! function_exists( 'gmr_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_entry_footer() {
		global $post;
		// Hide category and tag text for pages.
		if ( is_singular( array( 'post', 'tv' ) ) ) {
			/* translators: used between list items, there is a space after the comma */
			$categories_list = get_the_category_list( esc_html__( ', ', 'muvipro' ) );
			echo '<span class="cat-links">';
			echo esc_html__( 'Posted in ', 'muvipro' );
			$categories_list = get_the_category_list( esc_html__( ', ', 'muvipro' ) );
			if ( $categories_list ) :
				echo $categories_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo ', ';
			endif;
			if ( ! is_wp_error( get_the_term_list( $post->ID, 'muviquality' ) ) ) {
				$termlist = get_the_term_list( $post->ID, 'muviquality' );
				if ( ! empty( $termlist ) ) {
					echo get_the_term_list( $post->ID, 'muviquality', '<span>', '</span>, <span>', '</span>' );
					echo ', ';
				}
			}
			if ( ! is_wp_error( get_the_term_list( $post->ID, 'muvicountry' ) ) ) {
				$termlist = get_the_term_list( $post->ID, 'muvicountry' );
				if ( ! empty( $termlist ) ) {
					echo get_the_term_list( $post->ID, 'muvicountry', '<span itemprop="contentLocation" itemscope="itemscope" itemtype="http://schema.org/Place">', '</span>, <span itemprop="contentLocation" itemscope="itemscope" itemtype="http://schema.org/Place">', '</span>' );
				}
			}
			echo '</span>';
			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '', esc_html__( ', ', 'muvipro' ) );
			if ( $tags_list ) {
				echo '<span class="tags-links">' . esc_html__( 'Tagged ', 'muvipro' ) . $tags_list . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			/* translators: %s: post title */
			comments_popup_link( sprintf( wp_kses( __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'muvipro' ), array( 'span' => array( 'class' => array() ) ) ), get_the_title() ) );
			echo '</span>';
		}

		edit_post_link(
			sprintf(
				/* translators: %s: Name of current post */
				esc_html__( 'Edit %s', 'muvipro' ),
				the_title( '<span class="screen-reader-text">"', '"</span>', false )
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
endif; // endif gmr_entry_footer.

if ( ! function_exists( 'gmr_custom_excerpt_length' ) ) :
	/**
	 * Filter the except length to 20 characters.
	 *
	 * @since 1.0.0
	 *
	 * @param int $length Excerpt length.
	 * @return int (Maybe) modified excerpt length.
	 */
	function gmr_custom_excerpt_length( $length ) {
		$length = get_theme_mod( 'gmr_excerpt_number', '20' );
		// absint sanitize int non minus.
		return absint( $length );
	}
endif; // endif gmr_custom_excerpt_length
add_filter( 'excerpt_length', 'gmr_custom_excerpt_length', 999 );

if ( ! function_exists( 'gmr_custom_readmore' ) ) :
	/**
	 * Filter the except length to 20 characters.
	 *
	 * @since 1.0.0
	 *
	 * @param string $more Read More Button.
	 * @return string read more.
	 */
	function gmr_custom_readmore( $more ) {
		$more = get_theme_mod( 'gmr_read_more' );
		if ( empty( $more ) ) {
			return '&nbsp;[&hellip;]';
		} else {
			return ' <a class="read-more" href="' . get_permalink( get_the_ID() ) . '" title="' . get_the_title( get_the_ID() ) . '" ' . muvipro_itemprop_schema( 'url' ) . '>' . esc_html( $more ) . '</a>';
		}
	}
endif; // endif gmr_custom_readmore.
add_filter( 'excerpt_more', 'gmr_custom_readmore' );

if ( ! function_exists( 'gmr_get_pagination' ) ) :
	/**
	 * Retrieve paginated link for archive post pages.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	function gmr_get_pagination() {
		global $wp_rewrite;
		global $wp_query;
		return paginate_links(
			apply_filters(
				'gmr_get_pagination_args',
				array(
					'base'      => str_replace( '99999', '%#%', esc_url( get_pagenum_link( 99999 ) ) ),
					'format'    => $wp_rewrite->using_permalinks() ? 'page/%#%' : '?paged=%#%',
					'current'   => max( 1, get_query_var( 'paged' ) ),
					'total'     => $wp_query->max_num_pages,
					'prev_text' => '<span class="gmr-icon arrow_carrot-2left"></span>',
					'next_text' => '<span class="gmr-icon arrow_carrot-2right"></span>',
					'type'      => 'list',
				)
			)
		);
	}
endif; // endif gmr_get_pagination.

if ( ! function_exists( 'gmr_top_searchbutton' ) ) :
	/**
	 * This function add search button in header
	 *
	 * @since 1.0.0
	 */
	function gmr_top_searchbutton() {
		echo '<div class="gmr-search">';
			echo '<a id="search-menu-button-top" class="responsive-searchbtn pull-right" href="#" rel="nofollow"><span class="icon_search"></span></a>';
			echo '<form method="get" class="gmr-searchform searchform topsearchform" action="' . esc_url( home_url( '/' ) ) . '">';
				echo '<input type="text" name="s" id="s" placeholder="' . esc_html__( 'Search Movie', 'muvipro' ) . '" />';
				echo '<input type="hidden" name="post_type[]" value="post">';
				echo '<input type="hidden" name="post_type[]" value="tv">';
			echo '</form>';
		echo '</div>';
	}
endif; // endif gmr_top_searchbutton.
add_action( 'gmr_top_searchbutton', 'gmr_top_searchbutton', 5 );

if ( ! function_exists( 'muvipro_add_menu_attribute' ) ) :
	/**
	 * Add attribute itemprop="url" to menu link
	 *
	 * @since 1.0.0
	 *
	 * @param string $atts Atts.
	 * @param string $item Items.
	 * @param array  $args Args.
	 * @return string
	 */
	function muvipro_add_menu_attribute( $atts, $item, $args ) {
		$atts['itemprop'] = 'url';
		return $atts;
	}
endif; // endif muvipro_add_menu_attribute.
add_filter( 'nav_menu_link_attributes', 'muvipro_add_menu_attribute', 10, 3 );

if ( ! function_exists( 'gmr_the_custom_logo' ) ) :
	/**
	 * Print custom logo.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_the_custom_logo() {
		echo '<div class="gmr-logomobile">';
		echo '<div class="gmr-logo">';
		// if get value from customizer gmr_logoimage.
		$setting = 'gmr_logoimage';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			// get url image from value gmr_logoimage.
			echo '<a href="' . esc_url( home_url( '/' ) ) . '" class="custom-logo-link" ' . muvipro_itemprop_schema( 'url' ) . ' title="' . esc_html( get_bloginfo( 'name' ) ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<img src="' . esc_url_raw( $mod ) . '" alt="' . esc_html( get_bloginfo( 'name' ) ) . '" title="' . esc_html( get_bloginfo( 'name' ) ) . '" />';
			echo '</a>';

		} else {
			// if get value from customizer blogname.
			if ( get_theme_mod( 'blogname', get_bloginfo( 'name' ) ) ) {
				echo '<div class="site-title" ' . muvipro_itemprop_schema( 'headline' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<a href="' . esc_url( home_url( '/' ) ) . '" ' . muvipro_itemprop_schema( 'url' ) . ' title="' . esc_html( get_theme_mod( 'blogname', get_bloginfo( 'name' ) ) ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo esc_html( get_theme_mod( 'blogname', get_bloginfo( 'name' ) ) );
					echo '</a>';
				echo '</div>';

			}
			// if get value from customizer blogdescription.
			if ( get_theme_mod( 'blogdescription', get_bloginfo( 'description' ) ) ) {
				echo '<span class="site-description" ' . muvipro_itemprop_schema( 'description' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo esc_html( get_theme_mod( 'blogdescription', get_bloginfo( 'description' ) ) );
				echo '</span>';

			}
		}
		echo '</div>';
		echo '</div>';
	}
endif; // endif gmr_the_custom_logo.
add_action( 'gmr_the_custom_logo', 'gmr_the_custom_logo', 5 );

if ( ! function_exists( 'gmr_move_post_navigation' ) ) :
	/**
	 * Move post navigation in top after content.
	 *
	 * @param string $content Contents.
	 * @since 1.0.0
	 *
	 * @return string $content
	 */
	function gmr_move_post_navigation( $content ) {
		if ( is_singular() && in_the_loop() ) {
			$pagination = wp_link_pages(
				array(
					'before'      => '<div class="page-links"><span class="page-text">' . esc_html__( 'Pages:', 'muvipro' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span class="page-link-number">',
					'link_after'  => '</span>',
					'echo'        => 0,
				)
			);

			$content .= $pagination;
			return $content;
		}
		return $content;
	}
endif; // endif gmr_move_post_navigation.
add_filter( 'the_content', 'gmr_move_post_navigation', 1 );

if ( ! function_exists( 'gmr_embed_oembed_html' ) ) :
	/**
	 * Add responsive oembed class only for youtube and vimeo.
	 *
	 * @add_filter embed_oembed_html
	 * @class gmr_embed_oembed_html
	 * @param string $html displaying html Format.
	 * @param string $url url ombed like youtube, video.
	 * @param string $attr Attribute Iframe.
	 * @param int    $post_id Post ID.
	 * @link https://developer.wordpress.org/reference/hooks/embed_oembed_html/
	 */
	function gmr_embed_oembed_html( $html, $url, $attr, $post_id ) {
		$classes = array();
		/* Add these classes to all embeds. */
		$classes_all = array(
			'gmr-video-responsive',
		);

		/* Check for different providers and add appropriate classes. */
		if ( false !== strpos( $url, 'vimeo.com' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		if ( false !== strpos( $url, 'youtube.com' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		if ( false !== strpos( $url, 'youtu.be' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		$classes = array_merge( $classes, $classes_all );

		return '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">' . $html . '</div>';
	}
endif; /* endif gmr_embed_oembed_html */
add_filter( 'embed_oembed_html', 'gmr_embed_oembed_html', 99, 4 );

if ( ! function_exists( 'muvipro_prepend_attachment' ) ) :
	/**
	 * Callback for WordPress 'prepend_attachment' filter.
	 *
	 * Change the attachment page image size to 'large'
	 *
	 * @package WordPress
	 * @category Attachment
	 * @see wp-includes/post-template.php
	 *
	 * @param string $attachment_content the attachment html.
	 * @return string $attachment_content the attachment html
	 */
	function muvipro_prepend_attachment( $attachment_content ) {

		$post = get_post();
		if ( wp_attachment_is( 'image', $post ) ) {
			// set the attachment image size to 'full'.
			$attachment_content = sprintf( '<p>%s</p>', wp_get_attachment_link( 0, 'full', false ) );

			// return the attachment content.
			return $attachment_content;

		} else {
			// return the attachment content.
			return $attachment_content;
		}

	}
endif; // endif muvipro_prepend_attachment.
add_filter( 'prepend_attachment', 'muvipro_prepend_attachment' );

if ( ! function_exists( 'gmr_video_download' ) ) :
	/**
	 * Print video download link
	 *
	 * @param string $content Contents.
	 * @since 1.0.0
	 *
	 * @return String
	 */
	function gmr_video_download( $content ) {
		global $post;
		if ( is_singular( array( 'post', 'episode' ) ) && in_the_loop() ) {
			$download1      = get_post_meta( $post->ID, 'IDMUVICORE_Download1', true );
			$titledownload1 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download1', true );

			$download2      = get_post_meta( $post->ID, 'IDMUVICORE_Download2', true );
			$titledownload2 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download2', true );

			$download3      = get_post_meta( $post->ID, 'IDMUVICORE_Download3', true );
			$titledownload3 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download3', true );

			$download4      = get_post_meta( $post->ID, 'IDMUVICORE_Download4', true );
			$titledownload4 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download4', true );

			$download5      = get_post_meta( $post->ID, 'IDMUVICORE_Download5', true );
			$titledownload5 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download5', true );

			$download6      = get_post_meta( $post->ID, 'IDMUVICORE_Download6', true );
			$titledownload6 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download6', true );

			$download7      = get_post_meta( $post->ID, 'IDMUVICORE_Download7', true );
			$titledownload7 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download7', true );

			$download8      = get_post_meta( $post->ID, 'IDMUVICORE_Download8', true );
			$titledownload8 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download8', true );

			$download9      = get_post_meta( $post->ID, 'IDMUVICORE_Download9', true );
			$titledownload9 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download9', true );

			$download10      = get_post_meta( $post->ID, 'IDMUVICORE_Download10', true );
			$titledownload10 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download10', true );

			$download11      = get_post_meta( $post->ID, 'IDMUVICORE_Download11', true );
			$titledownload11 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download11', true );

			$download12      = get_post_meta( $post->ID, 'IDMUVICORE_Download12', true );
			$titledownload12 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download12', true );

			$download13      = get_post_meta( $post->ID, 'IDMUVICORE_Download13', true );
			$titledownload13 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download13', true );

			$download14      = get_post_meta( $post->ID, 'IDMUVICORE_Download14', true );
			$titledownload14 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download14', true );

			$download15      = get_post_meta( $post->ID, 'IDMUVICORE_Download15', true );
			$titledownload15 = get_post_meta( $post->ID, 'IDMUVICORE_Title_Download15', true );

			if ( ! empty( $download1 ) ) {
				$content .= '<div id="download" class="gmr-download-wrap clearfix">';
				$content .= '<h3 class="title-download">' . __( 'Download ', 'muvipro' ) . get_the_title() . '</h3>';

				$textbeforedownload = get_theme_mod( 'gmr_textbeforedownload' );

				if ( ! empty( $textbeforedownload ) ) {
					$content .= '<div class="gmr-textbeforedownload">';
					$content .= wp_kses_post( $textbeforedownload );
					$content .= '</div>';
				}
				$content .= '<ul class="list-inline gmr-download-list clearfix">';
				if ( ! empty( $download1 ) ) {
					$content .= '<li><a href="' . $download1 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 1', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload1 ) ) {
						$content .= $titledownload1;
					} else {
						$content .= __( 'Download Link 1', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download2 ) ) {
					$content .= '<li><a href="' . $download2 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 2', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload2 ) ) {
						$content .= $titledownload2;
					} else {
						$content .= __( 'Download Link 2', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download3 ) ) {
					$content .= '<li><a href="' . $download3 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 3', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload3 ) ) {
						$content .= $titledownload3;
					} else {
						$content .= __( 'Download Link 3', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download4 ) ) {
					$content .= '<li><a href="' . $download4 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 4', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload4 ) ) {
						$content .= $titledownload4;
					} else {
						$content .= __( 'Download Link 4', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download5 ) ) {
					$content .= '<li><a href="' . $download5 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 5', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload5 ) ) {
						$content .= $titledownload5;
					} else {
						$content .= __( 'Download Link 5', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download6 ) ) {
					$content .= '<li><a href="' . $download6 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 6', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload6 ) ) {
						$content .= $titledownload6;
					} else {
						$content .= __( 'Download Link 6', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download7 ) ) {
					$content .= '<li><a href="' . $download7 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 7', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload7 ) ) {
						$content .= $titledownload7;
					} else {
						$content .= __( 'Download Link 7', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download8 ) ) {
					$content .= '<li><a href="' . $download8 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 8', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload8 ) ) {
						$content .= $titledownload8;
					} else {
						$content .= __( 'Download Link 8', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download9 ) ) {
					$content .= '<li><a href="' . $download9 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 9', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload9 ) ) {
						$content .= $titledownload9;
					} else {
						$content .= __( 'Download Link 9', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download10 ) ) {
					$content .= '<li><a href="' . $download10 . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . __( 'Download link 10', 'muvipro' ) . ' ' . get_the_title() . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload10 ) ) {
						$content .= $titledownload10;
					} else {
						$content .= __( 'Download Link 10', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download11 ) ) {
					$content .= '<li><a href="' . esc_url( $download11 ) . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . esc_html__( 'Download link 11', 'muvipro' ) . ' ' . esc_html( get_the_title() ) . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload11 ) ) {
						$content .= esc_html( $titledownload11 );
					} else {
						$content .= esc_html__( 'Download Link 11', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download12 ) ) {
					$content .= '<li><a href="' . esc_url( $download12 ) . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . esc_html__( 'Download link 12', 'muvipro' ) . ' ' . esc_html( get_the_title() ) . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload12 ) ) {
						$content .= esc_html( $titledownload12 );
					} else {
						$content .= esc_html__( 'Download Link 12', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download13 ) ) {
					$content .= '<li><a href="' . esc_url( $download13 ) . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . esc_html__( 'Download link 13', 'muvipro' ) . ' ' . esc_html( get_the_title() ) . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload13 ) ) {
						$content .= esc_html( $titledownload13 );
					} else {
						$content .= esc_html__( 'Download Link 13', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download14 ) ) {
					$content .= '<li><a href="' . esc_url( $download14 ) . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . esc_html__( 'Download link 14', 'muvipro' ) . ' ' . esc_html( get_the_title() ) . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload14 ) ) {
						$content .= esc_html( $titledownload14 );
					} else {
						$content .= esc_html__( 'Download Link 14', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				if ( ! empty( $download15 ) ) {
					$content .= '<li><a href="' . esc_url( $download15 ) . '" class="button button-shadow" rel="nofollow" target="_blank" title="' . esc_html__( 'Download link 15', 'muvipro' ) . ' ' . esc_html( get_the_title() ) . '"><span class="icon_download" aria-hidden="true"></span>';
					if ( ! empty( $titledownload15 ) ) {
						$content .= esc_html( $titledownload15 );
					} else {
						$content .= esc_html__( 'Download Link 15', 'muvipro' );
					}
					$content .= '</a></li>';
				}

				$content .= '</ul>';
				$content .= '</div>';

			}

			return $content;
		}
		return $content;
	}
endif; // endif gmr_video_download.
add_filter( 'the_content', 'gmr_video_download', 4 );

if ( ! function_exists( 'gmr_tvshow_serie_list' ) ) :
	/**
	 * Print Series list
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_tvshow_serie_list() {
		global $post;
		if ( is_singular( array( 'tv', 'episode' ) ) && in_the_loop() ) {
			$post_id = $post->ID; // current post ID.
			$tmdbid  = get_post_meta( $post->ID, 'IDMUVICORE_tmdbID', true );
			if ( ! empty( $tmdbid ) ) {
				$args = array(
					'post_type'      => 'episode',
					'posts_per_page' => -1,
					// fix title with number.
					'orderby'        => 'wp_posts.post_title+0',
					'order'          => 'ASC',
					'meta_query'     => array(
						array(
							'key'     => 'IDMUVICORE_tmdbID',
							'value'   => $tmdbid,
							'compare' => '=',
						),
					),
				);

				$episode = new WP_Query( $args );
				$temp    = get_the_ID();
				if ( $episode->have_posts() ) {
					echo '<div class="gmr-listseries">';
					while ( $episode->have_posts() ) :
						$episode->the_post();
						$epsnumber  = get_post_meta( $post->ID, 'IDMUVICORE_Episodenumber', true );
						$sessnumber = get_post_meta( $post->ID, 'IDMUVICORE_Sessionnumber', true );
						if ( ! empty( $epsnumber ) ) {
							$eps = esc_html__( 'Eps', 'muvipro' ) . $epsnumber;
						} else {
							$eps = esc_html__( 'No Eps', 'muvipro' );
						}
						if ( ! empty( $sessnumber ) ) {
							$sess = esc_html__( 'S', 'muvipro' ) . $sessnumber . ' ';
						} else {
							$sess = '';
						}
						$class = ( get_the_ID() === $temp ) ? ' active' : '';
						echo '<a class="button button-shadow' . esc_html( $class ) . '" href="' . esc_url( get_permalink() ) . '" title="' . esc_html__( 'Permalink to', 'muvipro' ) . ' ' . esc_html( get_the_title() ) . '">' . esc_html( $sess ) . esc_html( $eps ) . '</a>';
					endwhile;
					echo '</div>';
				}
				wp_reset_postdata();
			}
		}
	}
endif;
add_action( 'gmr_tvshow_serie_list', 'gmr_tvshow_serie_list', 3 );

if ( ! function_exists( 'gmr_get_prevnext_episode' ) ) :
	/**
	 * Retrieve prev and next episode
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_get_prevnext_episode() {
		global $post;
		if ( is_singular( 'episode' ) && in_the_loop() ) {
			$post_id = $post->ID; // current post ID.

			$tmdbid = get_post_meta( $post->ID, 'IDMUVICORE_tmdbID', true );
			if ( ! empty( $tmdbid ) ) {

				$args = array(
					'post_type'      => 'episode',
					'posts_per_page' => -1,
					// fix title with number.
					'orderby'        => 'wp_posts.post_title+0',
					'order'          => 'ASC',
					'meta_query'     => array(
						array(
							'key'     => 'IDMUVICORE_tmdbID',
							'value'   => $tmdbid,
							'compare' => '=',
						),
					),
				);

				$posts = get_posts( $args );
				// get IDs of posts retrieved from get_posts.
				$ids = array();
				foreach ( $posts as $thepost ) {
					$ids[] = $thepost->ID;
				}
				// get and echo previous and next post in the same category.
				$thisindex = array_search( $post_id, $ids, true );
				$previd    = isset( $ids[ $thisindex - 1 ] ) ? $ids[ $thisindex - 1 ] : null;
				$nextid    = isset( $ids[ $thisindex + 1 ] ) ? $ids[ $thisindex + 1 ] : null;

				if ( ! empty( $previd ) || ! empty( $nextid ) ) {
					echo '<nav class="pull-right" role="navigation">';
				}
				if ( ! empty( $previd ) ) {
					echo '<a href="' . esc_url( get_permalink( $previd ) ) . '" class="button button-shadow" title="' . esc_html__( 'Permalink to: ', 'muvipro' ) . esc_html( get_the_title( $previd ) ) . '" rel="previous"><span class="arrow_carrot-2left"></span></a>';
				}

				if ( ! empty( $nextid ) ) {
					echo '<a href="' . esc_url( get_permalink( $nextid ) ) . '"  class="button button-shadow" title="' . esc_html__( 'Permalink to: ', 'muvipro' ) . esc_html( get_the_title( $nextid ) ) . '" rel="next"><span class="arrow_carrot-2right"></span></a>';
				}
				if ( ! empty( $previd ) || ! empty( $nextid ) ) {
					echo '</nav>';
				}
			}
		}
	}
endif; // endif gmr_get_prevnext_episode.
add_action( 'gmr_get_prevnext_episode', 'gmr_get_prevnext_episode', 5 );

if ( ! function_exists( 'gmr_socialicon' ) ) :
	/**
	 * Add social icon
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_socialicon() {
		?>
		<div class="gmr-social-icon clearfix">
			<?php
			$filter_title = str_replace( ' ', '%20', get_bloginfo( 'name' ) );
			echo '<ul class="pull-left gmr-socialicon-share">';

			echo '<li class="facebook">';
			echo '<a href="#" class="share-facebook" onclick="popUp=window.open(\'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( home_url( '/' ) ) . '\', \'popupwindow\', \'scrollbars=yes,height=300,width=550\');popUp.focus();return false" rel="nofollow" title="' . esc_html__( 'Share this', 'muvipro' ) . '">';
			echo '<span class="social_facebook"></span>';
			echo esc_html__( 'Sharer', 'muvipro' );
			echo '</a>';
			echo '</li>';

			echo '<li class="twitter">';
			echo '<a href="#" class="share-twitter" onclick="popUp=window.open(\'https://twitter.com/share?url=' . esc_url( home_url( '/' ) ) . '&amp;text=' . esc_html( $filter_title ) . '\', \'popupwindow\', \'scrollbars=yes,height=300,width=550\');popUp.focus();return false" rel="nofollow" title="' . esc_html__( 'Tweet this', 'muvipro' ) . '">';
			echo '<span class="social_twitter"></span>';
			echo esc_html__( 'Tweet', 'muvipro' );
			echo '</a>';
			echo '</li>';

			echo '<li class="whatsapp">';
			echo '<a class="share-whatsapp" href="https://api.whatsapp.com/send?text=' . $filter_title . '%20' . rawurlencode( esc_url( home_url( '/' ) ) ) . '" rel="nofollow" title="' . esc_html__( 'Whatsapp', 'muvipro' ) . '">';  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo esc_html__( 'WhatsApp', 'muvipro' );
			echo '</a>';
			echo '</li>';

			echo '</ul>';

			echo '<ul class="pull-right social-icon">';
			$fb_url = get_theme_mod( 'gmr_fb_url_icon' );
			if ( $fb_url ) :
				echo '<li><a href="' . esc_url( $fb_url ) . '" title="' . esc_html__( 'Facebook', 'muvipro' ) . '" rel="nofollow"><span class="social_facebook"></span></a></li>';
			endif;

			$twitter_url = get_theme_mod( 'gmr_twitter_url_icon' );
			if ( $twitter_url ) :
				echo '<li><a href="' . esc_url( $twitter_url ) . '" title="' . esc_html__( 'Twitter', 'muvipro' ) . '" rel="nofollow"><span class="social_twitter"></span></a></li>';
			endif;

			$pinterest_url = get_theme_mod( 'gmr_pinterest_url_icon' );
			if ( $pinterest_url ) :
				echo '<li><a href="' . esc_url( $pinterest_url ) . '" title="' . esc_html__( 'Pinterest', 'muvipro' ) . '" rel="nofollow"><span class="social_pinterest"></span></a></li>';
			endif;

			$tumblr_url = get_theme_mod( 'gmr_tumblr_url_icon' );
			if ( $tumblr_url ) :
				echo '<li><a href="' . esc_url( $tumblr_url ) . '" title="' . esc_html__( 'Tumblr', 'muvipro' ) . '" rel="nofollow"><span class="social_tumblr"></span></a></li>';
			endif;

			$stumbleupon_url = get_theme_mod( 'gmr_stumbleupon_url_icon' );
			if ( $stumbleupon_url ) :
				echo '<li><a href="' . esc_url( $stumbleupon_url ) . '" title="' . esc_html__( 'Stumbleupon', 'muvipro' ) . '" rel="nofollow"><span class="social_tumbleupon"></span></a></li>';
			endif;

			$wordpress_url = get_theme_mod( 'gmr_wordpress_url_icon' );
			if ( $wordpress_url ) :
				echo '<li><a href="' . esc_url( $wordpress_url ) . '" title="' . esc_html__( 'WordPress', 'muvipro' ) . '" rel="nofollow"><span class="social_wordpress"></span></a></li>';
			endif;

			$instagram_url = get_theme_mod( 'gmr_instagram_url_icon' );
			if ( $instagram_url ) :
				echo '<li><a href="' . esc_url( $instagram_url ) . '" title="' . esc_html__( 'Instagram', 'muvipro' ) . '" rel="nofollow"><span class="social_instagram"></span></a></li>';
			endif;

			$dribbble_url = get_theme_mod( 'gmr_dribbble_url_icon' );
			if ( $dribbble_url ) :
				echo '<li><a href="' . esc_url( $dribbble_url ) . '" title="' . esc_html__( 'Dribbble', 'muvipro' ) . '" rel="nofollow"><span class="social_dribbble"></span></a></li>';
			endif;

			$vimeo_url = get_theme_mod( 'gmr_vimeo_url_icon' );
			if ( $vimeo_url ) :
				echo '<li><a href="' . esc_url( $vimeo_url ) . '" title="' . esc_html__( 'Vimeo', 'muvipro' ) . '" rel="nofollow"><span class="social_vimeo"></span></a></li>';
			endif;

			$linkedin_url = get_theme_mod( 'gmr_linkedin_url_icon' );
			if ( $linkedin_url ) :
				echo '<li><a href="' . esc_url( $linkedin_url ) . '" title="' . esc_html__( 'Linkedin', 'muvipro' ) . '" rel="nofollow"><span class="social_linkedin"></span></a></li>';
			endif;

			$deviantart_url = get_theme_mod( 'gmr_deviantart_url_icon' );
			if ( $deviantart_url ) :
				echo '<li><a href="' . esc_url( $deviantart_url ) . '" title="' . esc_html__( 'Deviantart', 'muvipro' ) . '" rel="nofollow"><span class="social_deviantart"></span></a></li>';
			endif;

			$myspace_url = get_theme_mod( 'gmr_myspace_url_icon' );
			if ( $myspace_url ) :
				echo '<li><a href="' . esc_url( $myspace_url ) . '" title="' . esc_html__( 'Myspace', 'muvipro' ) . '" rel="nofollow"><span class="social_myspace"></span></a></li>';
			endif;

			$skype_url = get_theme_mod( 'gmr_skype_url_icon' );
			if ( $skype_url ) :
				echo '<li><a href="' . esc_url( $skype_url ) . '" title="' . esc_html__( 'Skype', 'muvipro' ) . '" rel="nofollow"><span class="social_skype"></span></a></li>';
			endif;

			$youtube_url = get_theme_mod( 'gmr_youtube_url_icon' );
			if ( $youtube_url ) :
				echo '<li><a href="' . esc_url( $youtube_url ) . '" title="' . esc_html__( 'Youtube', 'muvipro' ) . '" rel="nofollow"><span class="social_youtube"></span></a></li>';
			endif;

			$picassa_url = get_theme_mod( 'gmr_picassa_url_icon' );
			if ( $picassa_url ) :
				echo '<li><a href="' . esc_url( $picassa_url ) . '" title="' . esc_html__( 'Picassa', 'muvipro' ) . '" rel="nofollow"><span class="social_picassa"></span></a></li>';
			endif;

			$flickr_url = get_theme_mod( 'gmr_flickr_url_icon' );
			if ( $flickr_url ) :
				echo '<li><a href="' . esc_url( $flickr_url ) . '" title="' . esc_html__( 'Flickr', 'muvipro' ) . '" rel="nofollow"><span class="social_flickr"></span></a></li>';
			endif;

			$blogger_url = get_theme_mod( 'gmr_blogger_url_icon' );
			if ( $blogger_url ) :
				echo '<li><a href="' . esc_url( $blogger_url ) . '" title="' . esc_html__( 'Blogger', 'muvipro' ) . '" rel="nofollow"><span class="social_blogger"></span></a></li>';
			endif;

			$spotify_url = get_theme_mod( 'gmr_spotify_url_icon' );
			if ( $spotify_url ) :
				echo '<li><a href="' . esc_url( $spotify_url ) . '" title="' . esc_html__( 'Spotify', 'muvipro' ) . '" rel="nofollow"><span class="social_spotify"></span></a></li>';
			endif;

			$delicious_url = get_theme_mod( 'gmr_delicious_url_icon' );
			if ( $delicious_url ) :
				echo '<li><a href="' . esc_url( $delicious_url ) . '" title="' . esc_html__( 'Delicious', 'muvipro' ) . '" rel="nofollow"><span class="social_delicious"></span></a></li>';
			endif;

			// Disable rss icon via customizer.
			$rssicon = get_theme_mod( 'gmr_active-rssicon', 0 );
			if ( 0 === $rssicon ) :
				echo '<li><a href="' . esc_url( get_bloginfo( 'rss2_url' ) ) . '" title="' . esc_html__( 'RSS', 'muvipro' ) . '" rel="nofollow"><span class="social_rss"></span></a></li>';
			endif;
			echo '</ul>';
			?>
		</div>
		<?php
	}
endif;
add_action( 'gmr_socialicon', 'gmr_socialicon', 5 );

if ( ! function_exists( 'muvipro_share_default' ) ) :
	/**
	 * Insert social share
	 *
	 * @param string $output Output.
	 * @since 1.0.0
	 * @return string @output
	 */
	function muvipro_share_default( $output = null ) {
		$socialshare = get_theme_mod( 'gmr_active-socialshare', 0 );

		if ( 0 === $socialshare ) {

			$filter_title = str_replace( ' ', '%20', get_the_title() );

			$output  = '';
			$output .= '<div class="idmuvi-social-share">';
			$output .= '<ul class="idmuvi-socialicon-share">';

				$output .= '<li class="facebook">';
				$output .= '<a href="#" class="idmuvi-sharebtn idmuvi-facebook" onclick="popUp=window.open(\'https://www.facebook.com/sharer/sharer.php?u=' . get_the_permalink() . '\', \'popupwindow\', \'scrollbars=yes,height=300,width=550\');popUp.focus();return false" rel="nofollow" title="' . __( 'Share this', 'muvipro' ) . '"><span class="social_facebook"></span>';
				$output .= __( 'Sharer', 'muvipro' );
				$output .= '</a>';
				$output .= '</li>';

				$output .= '<li class="twitter">';
				$output .= '<a href="#" class="idmuvi-sharebtn idmuvi-twitter" onclick="popUp=window.open(\'https://twitter.com/share?url=' . get_the_permalink() . '&amp;text=' . $filter_title . '\', \'popupwindow\', \'scrollbars=yes,height=300,width=550\');popUp.focus();return false" rel="nofollow" title="' . __( 'Tweet this', 'muvipro' ) . '"><span class="social_twitter"></span>';
				$output .= __( 'Tweet', 'muvipro' );
				$output .= '</a>';
				$output .= '</li>';

				$output .= '<li class="whatsapp">';
				$output .= '<a class="idmuvi-sharebtn idmuvi-whatsapp" href="https://api.whatsapp.com/send?text=' . $filter_title . '%20' . rawurlencode( esc_url( get_permalink() ) ) . '" rel="nofollow" title="' . __( 'Whatsapp', 'muvipro' ) . '">';
				$output .= __( 'WhatsApp', 'muvipro' );
				$output .= '</a>';
				$output .= '</li>';

			$output .= '</ul>';
			$output .= '</div>';

		}

		return $output;
	}
endif; // endif muvipro_share_default.

if ( ! function_exists( 'muvipro_share_jetpack' ) ) :
	/**
	 * Displaying Share.
	 */
	function muvipro_share_jetpack() {
		if ( function_exists( 'sharing_display' ) ) {
			$share = sharing_display( '', false );
		} else {
			$share = muvipro_share_default();
		}

		if ( class_exists( 'Jetpack_Likes' ) ) {
			$custom_likes = new Jetpack_Likes();
			$share        = $custom_likes->post_likes( '' );
		}
		return $share;
	}
endif; // endif muvipro_share_jetpack.

if ( ! function_exists( 'muvipro_add_share_the_content' ) ) :
	/**
	 * Insert content after box content single
	 *
	 * @param string $content Content.
	 * @since 1.0.0
	 * @link https://jetpack.com/support/related-posts/customize-related-posts/#delete
	 * @return string
	 */
	function muvipro_add_share_the_content( $content ) {
		if ( is_single() && in_the_loop() ) {
			$content = $content . muvipro_share_jetpack();
		}
		return $content;
	}
endif; // endif muvipro_add_share_the_content.
add_filter( 'the_content', 'muvipro_add_share_the_content', 30 );

if ( ! function_exists( 'muvipro_share_action' ) ) :
	/**
	 * Add action for share display
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function muvipro_share_action() {
		echo muvipro_share_jetpack(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
endif;
add_action( 'muvipro_share_action', 'muvipro_share_action', 5 );
