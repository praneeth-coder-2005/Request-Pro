<?php
/**
 * Import Processor Class
 * 
 * Handles the processing and importing of TMDB data into WordPress
 */

if (!defined('ABSPATH')) {
    exit;
}

class ETMDB_Import_Processor {
    
    private $tmdb_api;
    private $settings;
    
    public function __construct() {
        $this->tmdb_api = new ETMDB_API();
        $this->settings = get_option('etmdb_settings', array());
    }
    
    /**
     * Import a single movie or TV show
     */
    public function import_single($tmdb_id, $type) {
        try {
            // Check if already imported
            if ($this->is_already_imported($tmdb_id, $type)) {
                return array(
                    'success' => false,
                    'message' => __('This item has already been imported.', 'enhanced-tmdb-importer')
                );
            }
            
            // Get detailed data from TMDB
            if ($type === 'movie') {
                $data = $this->tmdb_api->get_movie_details($tmdb_id);
            } else {
                $data = $this->tmdb_api->get_tv_details($tmdb_id);
            }
            
            if (is_wp_error($data)) {
                return array(
                    'success' => false,
                    'message' => $data->get_error_message()
                );
            }
            
            // Create WordPress post
            $post_id = $this->create_post($data, $type);
            
            if (is_wp_error($post_id)) {
                return array(
                    'success' => false,
                    'message' => $post_id->get_error_message()
                );
            }
            
            // Save metadata
            $this->save_metadata($post_id, $data);
            
            // Handle featured image
            if (!empty($data['poster_path']) && $this->get_setting('auto_set_featured_image', true)) {
                $this->set_featured_image($post_id, $data['poster_path'], $data['title']);
            }
            
            // Handle taxonomies
            $this->handle_taxonomies($post_id, $data, $type);
            
            // Log import
            $this->log_import($tmdb_id, $post_id, $type, $data['title']);
            
            return array(
                'success' => true,
                'message' => sprintf(__('%s imported successfully!', 'enhanced-tmdb-importer'), $data['title']),
                'post_id' => $post_id,
                'edit_url' => get_edit_post_link($post_id)
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * Bulk import multiple items
     */
    public function bulk_import($items) {
        $results = array(
            'success' => 0,
            'failed' => 0,
            'skipped' => 0,
            'details' => array()
        );
        
        $batch_size = $this->get_setting('batch_size', 5);
        $processed = 0;
        
        foreach ($items as $item) {
            if ($processed >= $batch_size) {
                break; // Process in batches to avoid timeouts
            }
            
            $result = $this->import_single($item['tmdb_id'], $item['type']);
            
            if ($result['success']) {
                $results['success']++;
            } else {
                if (strpos($result['message'], 'already been imported') !== false) {
                    $results['skipped']++;
                } else {
                    $results['failed']++;
                }
            }
            
            $results['details'][] = array(
                'title' => $item['title'],
                'status' => $result['success'] ? 'success' : 'failed',
                'message' => $result['message']
            );
            
            $processed++;
        }
        
        return $results;
    }
    
    /**
     * Create WordPress post
     */
    private function create_post($data, $type) {
        $post_type = $type === 'movie' ? 'post' : 'tv';
        
        $post_data = array(
            'post_title' => $data['title'],
            'post_content' => $data['overview'],
            'post_status' => 'publish',
            'post_type' => $post_type,
            'post_author' => get_current_user_id()
        );
        
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        
        return $post_id;
    }
    
    /**
     * Save metadata to post
     */
    private function save_metadata($post_id, $data) {
        $meta_mapping = array(
            'IDMUVICORE_tmdbID' => $data['id'],
            'IDMUVICORE_Title' => $data['title'],
            'IDMUVICORE_tmdbRating' => $data['vote_average'],
            'IDMUVICORE_tmdbVotes' => $data['vote_count'],
            'IDMUVICORE_Tagline' => $data['tagline'] ?? '',
            'IDMUVICORE_Language' => $data['original_language'],
            'IDMUVICORE_Rated' => $data['rating'] ?? ''
        );
        
        // Type-specific metadata
        if ($data['type'] === 'movie') {
            $meta_mapping['IDMUVICORE_Released'] = $data['release_date'];
            $meta_mapping['IDMUVICORE_Runtime'] = $data['runtime'];
            $meta_mapping['IDMUVICORE_Budget'] = $data['budget'];
            $meta_mapping['IDMUVICORE_Revenue'] = $data['revenue'];
            
            if (!empty($data['release_date'])) {
                $meta_mapping['IDMUVICORE_Year'] = date('Y', strtotime($data['release_date']));
            }
        } else {
            $meta_mapping['IDMUVICORE_Released'] = $data['first_air_date'];
            $meta_mapping['IDMUVICORE_Runtime'] = $data['episode_run_time'];
            
            if (!empty($data['first_air_date'])) {
                $meta_mapping['IDMUVICORE_Year'] = date('Y', strtotime($data['first_air_date']));
            }
        }
        
        // Add trailer URL if available
        if (!empty($data['trailer_url'])) {
            $meta_mapping['IDMUVICORE_Trailer'] = $data['trailer_url'];
        }
        
        // Save all metadata
        foreach ($meta_mapping as $meta_key => $meta_value) {
            if ($meta_value !== null && $meta_value !== '') {
                update_post_meta($post_id, $meta_key, $meta_value);
            }
        }
        
        // Save cast and crew if enabled
        if ($this->get_setting('import_cast_crew', true)) {
            if (!empty($data['cast'])) {
                update_post_meta($post_id, 'IDMUVICORE_Cast', $data['cast']);
            }
            if (!empty($data['crew'])) {
                update_post_meta($post_id, 'IDMUVICORE_Crew', $data['crew']);
            }
        }
        
        // Save additional images
        if (!empty($data['images'])) {
            update_post_meta($post_id, 'IDMUVICORE_Images', $data['images']);
        }
    }


    
    /**
     * Handle taxonomies (genres, countries, etc.)
     */
    private function handle_taxonomies($post_id, $data, $type) {
        // Handle genres
        if (!empty($data['genres']) && $this->get_setting('import_genres', true)) {
            $genre_ids = array();
            foreach ($data['genres'] as $genre_name) {
                $term = get_term_by('name', $genre_name, 'category');
                if (!$term) {
                    $term = wp_insert_term($genre_name, 'category');
                    if (!is_wp_error($term)) {
                        $genre_ids[] = $term['term_id'];
                    }
                } else {
                    $genre_ids[] = $term->term_id;
                }
            }
            if (!empty($genre_ids)) {
                wp_set_post_terms($post_id, $genre_ids, 'category');
            }
        }
        
        // Handle countries
        if (!empty($data['countries'])) {
            $country_names = is_array($data['countries']) ? $data['countries'] : array($data['countries']);
            $country_ids = array();
            
            foreach ($country_names as $country_name) {
                $term = get_term_by('name', $country_name, 'muvicountry');
                if (!$term) {
                    $term = wp_insert_term($country_name, 'muvicountry');
                    if (!is_wp_error($term)) {
                        $country_ids[] = $term['term_id'];
                    }
                } else {
                    $country_ids[] = $term->term_id;
                }
            }
            if (!empty($country_ids)) {
                wp_set_post_terms($post_id, $country_ids, 'muvicountry');
            }
        }
        
        // Handle year
        if (!empty($data['release_date']) || !empty($data['first_air_date'])) {
            $date = !empty($data['release_date']) ? $data['release_date'] : $data['first_air_date'];
            $year = date('Y', strtotime($date));
            
            $term = get_term_by('name', $year, 'muviyear');
            if (!$term) {
                $term = wp_insert_term($year, 'muviyear');
                if (!is_wp_error($term)) {
                    wp_set_post_terms($post_id, array($term['term_id']), 'muviyear');
                }
            } else {
                wp_set_post_terms($post_id, array($term->term_id), 'muviyear');
            }
        }
        
        // Handle networks for TV shows
        if ($type === 'tv' && !empty($data['networks'])) {
            $network_ids = array();
            foreach ($data['networks'] as $network_name) {
                $term = get_term_by('name', $network_name, 'muvinetwork');
                if (!$term) {
                    $term = wp_insert_term($network_name, 'muvinetwork');
                    if (!is_wp_error($term)) {
                        $network_ids[] = $term['term_id'];
                    }
                } else {
                    $network_ids[] = $term->term_id;
                }
            }
            if (!empty($network_ids)) {
                wp_set_post_terms($post_id, $network_ids, 'muvinetwork');
            }
        }
        
        // Handle keywords if enabled
        if (!empty($data['keywords']) && $this->get_setting('import_keywords', false)) {
            $keyword_names = array_slice($data['keywords'], 0, 10); // Limit to 10 keywords
            wp_set_post_terms($post_id, $keyword_names, 'post_tag');
        }
    }
    
    /**
     * Set featured image from URL
     */
    private function set_featured_image($post_id, $image_url, $title) {
        if (empty($image_url)) {
            return false;
        }
        
        // Check if image already exists
        $existing_attachment = $this->get_attachment_by_url($image_url);
        if ($existing_attachment) {
            set_post_thumbnail($post_id, $existing_attachment->ID);
            return true;
        }
        
        // Download and attach image
        $tmp = download_url($image_url);
        
        if (is_wp_error($tmp)) {
            return false;
        }
        
        $file_array = array(
            'name' => sanitize_file_name($title . '-poster.jpg'),
            'tmp_name' => $tmp
        );
        
        $attachment_id = media_handle_sideload($file_array, $post_id);
        
        if (is_wp_error($attachment_id)) {
            @unlink($file_array['tmp_name']);
            return false;
        }
        
        // Store original URL for future reference
        update_post_meta($attachment_id, '_tmdb_original_url', $image_url);
        
        set_post_thumbnail($post_id, $attachment_id);
        return true;
    }
    
    /**
     * Get attachment by original URL
     */
    private function get_attachment_by_url($url) {
        global $wpdb;
        
        $attachment = $wpdb->get_row($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_tmdb_original_url' AND meta_value = %s LIMIT 1",
            $url
        ));
        
        if ($attachment) {
            return get_post($attachment->post_id);
        }
        
        return false;
    }
    
    /**
     * Check if item is already imported
     */
    private function is_already_imported($tmdb_id, $type) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'etmdb_import_history';
        
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE tmdb_id = %d AND content_type = %s",
            $tmdb_id,
            $type
        ));
        
        return $result > 0;
    }
    
    /**
     * Log import to history
     */
    private function log_import($tmdb_id, $post_id, $type, $title) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'etmdb_import_history';
        
        $wpdb->insert(
            $table_name,
            array(
                'tmdb_id' => $tmdb_id,
                'post_id' => $post_id,
                'content_type' => $type,
                'title' => $title,
                'import_date' => current_time('mysql'),
                'status' => 'completed'
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get setting value
     */
    private function get_setting($key, $default = null) {
        return isset($this->settings[$key]) ? $this->settings[$key] : $default;
    }
    
    /**
     * Get import history
     */
    public function get_import_history($limit = 50, $offset = 0) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'etmdb_import_history';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} ORDER BY import_date DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        ));
        
        return $results;
    }
    
    /**
     * Get import statistics
     */
    public function get_import_stats() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'etmdb_import_history';
        
        $stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total_imports,
                COUNT(CASE WHEN content_type = 'movie' THEN 1 END) as movies_imported,
                COUNT(CASE WHEN content_type = 'tv' THEN 1 END) as tv_shows_imported,
                COUNT(CASE WHEN import_date >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as imports_last_30_days
            FROM {$table_name}"
        );
        
        return $stats;
    }
}
