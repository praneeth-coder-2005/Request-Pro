<?php
/**
 * Admin Interface Class
 * 
 * Handles the admin interface for the TMDB importer
 */

if (!defined('ABSPATH')) {
    exit;
}

class ETMDB_Admin_Interface {
    
    private $import_processor;
    
    public function __construct() {
        $this->import_processor = new ETMDB_Import_Processor();
    }
    
    /**
     * Render main search and import page
     */
    public function render_main_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('TMDB Search & Import', 'enhanced-tmdb-importer'); ?></h1>
            
            <div class="etmdb-search-container">
                <div class="etmdb-search-form">
                    <h2><?php _e('Search Movies & TV Shows', 'enhanced-tmdb-importer'); ?></h2>
                    
                    <form id="etmdb-search-form">
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="search-query"><?php _e('Search Query', 'enhanced-tmdb-importer'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="search-query" name="query" class="regular-text" placeholder="<?php _e('Enter movie or TV show title...', 'enhanced-tmdb-importer'); ?>" required>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="search-type"><?php _e('Content Type', 'enhanced-tmdb-importer'); ?></label>
                                </th>
                                <td>
                                    <select id="search-type" name="type">
                                        <option value="multi"><?php _e('Movies & TV Shows', 'enhanced-tmdb-importer'); ?></option>
                                        <option value="movie"><?php _e('Movies Only', 'enhanced-tmdb-importer'); ?></option>
                                        <option value="tv"><?php _e('TV Shows Only', 'enhanced-tmdb-importer'); ?></option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary" id="search-btn">
                                <?php _e('Search TMDB', 'enhanced-tmdb-importer'); ?>
                            </button>
                        </p>
                    </form>
                </div>
                
                <div id="etmdb-search-results" class="etmdb-results-container" style="display: none;">
                    <h3><?php _e('Search Results', 'enhanced-tmdb-importer'); ?></h3>
                    <div id="search-results-content"></div>
                    <div id="search-pagination"></div>
                </div>
            </div>
            
            <div id="etmdb-import-status" class="notice" style="display: none;"></div>
        </div>
        
        <style>
        .etmdb-search-container {
            max-width: 1200px;
        }
        
        .etmdb-results-container {
            margin-top: 30px;
            padding: 20px;
            background: #fff;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        
        .etmdb-result-item {
            display: flex;
            padding: 15px;
            border-bottom: 1px solid #eee;
            align-items: flex-start;
        }
        
        .etmdb-result-item:last-child {
            border-bottom: none;
        }
        
        .etmdb-result-poster {
            flex-shrink: 0;
            margin-right: 15px;
        }
        
        .etmdb-result-poster img {
            width: 80px;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .etmdb-result-info {
            flex-grow: 1;
        }
        
        .etmdb-result-title {
            font-size: 16px;
            font-weight: 600;
            margin: 0 0 5px 0;
        }
        
        .etmdb-result-meta {
            color: #666;
            font-size: 13px;
            margin-bottom: 8px;
        }
        
        .etmdb-result-overview {
            font-size: 14px;
            line-height: 1.4;
            margin-bottom: 10px;
        }
        
        .etmdb-result-actions {
            flex-shrink: 0;
            margin-left: 15px;
        }
        
        .etmdb-import-btn {
            background: #0073aa;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 13px;
        }
        
        .etmdb-import-btn:hover {
            background: #005a87;
        }
        
        .etmdb-import-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        .etmdb-type-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            margin-right: 8px;
        }
        
        .etmdb-type-movie {
            background: #e74c3c;
            color: white;
        }
        
        .etmdb-type-tv {
            background: #3498db;
            color: white;
        }
        
        .etmdb-rating {
            display: inline-block;
            background: #f39c12;
            color: white;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .etmdb-loading {
            text-align: center;
            padding: 40px;
        }
        
        .etmdb-no-results {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .etmdb-pagination {
            text-align: center;
            margin-top: 20px;
        }
        
        .etmdb-pagination button {
            margin: 0 5px;
            padding: 8px 12px;
            border: 1px solid #ccc;
            background: #f7f7f7;
            cursor: pointer;
        }
        
        .etmdb-pagination button:hover {
            background: #e6e6e6;
        }
        
        .etmdb-pagination button.current {
            background: #0073aa;
            color: white;
            border-color: #0073aa;
        }
        </style>
        <?php
    }
    
    /**
     * Render bulk import page
     */
    public function render_bulk_import_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Bulk Import', 'enhanced-tmdb-importer'); ?></h1>
            
            <div class="etmdb-bulk-container">
                <div class="etmdb-bulk-form">
                    <h2><?php _e('Import Multiple Items', 'enhanced-tmdb-importer'); ?></h2>
                    <p><?php _e('Enter TMDB IDs (one per line) or upload a CSV file with TMDB IDs and types.', 'enhanced-tmdb-importer'); ?></p>
                    
                    <form id="etmdb-bulk-form">
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="bulk-method"><?php _e('Import Method', 'enhanced-tmdb-importer'); ?></label>
                                </th>
                                <td>
                                    <select id="bulk-method" name="method">
                                        <option value="manual"><?php _e('Manual Entry', 'enhanced-tmdb-importer'); ?></option>
                                        <option value="csv"><?php _e('CSV Upload', 'enhanced-tmdb-importer'); ?></option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        
                        <div id="manual-entry" class="bulk-method-content">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="bulk-ids"><?php _e('TMDB IDs', 'enhanced-tmdb-importer'); ?></label>
                                    </th>
                                    <td>
                                        <textarea id="bulk-ids" name="ids" rows="10" cols="50" class="large-text" placeholder="<?php _e('Enter TMDB IDs, one per line. Format: ID,TYPE (e.g., 550,movie or 1399,tv)', 'enhanced-tmdb-importer'); ?>"></textarea>
                                        <p class="description">
                                            <?php _e('Format: TMDB_ID,TYPE (movie or tv). Example:', 'enhanced-tmdb-importer'); ?><br>
                                            550,movie<br>
                                            1399,tv<br>
                                            238,movie
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div id="csv-upload" class="bulk-method-content" style="display: none;">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="bulk-csv"><?php _e('CSV File', 'enhanced-tmdb-importer'); ?></label>
                                    </th>
                                    <td>
                                        <input type="file" id="bulk-csv" name="csv" accept=".csv">
                                        <p class="description">
                                            <?php _e('CSV should have columns: tmdb_id, type, title (optional)', 'enhanced-tmdb-importer'); ?>
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary" id="bulk-import-btn">
                                <?php _e('Start Bulk Import', 'enhanced-tmdb-importer'); ?>
                            </button>
                        </p>
                    </form>
                </div>
                
                <div id="etmdb-bulk-progress" class="etmdb-progress-container" style="display: none;">
                    <h3><?php _e('Import Progress', 'enhanced-tmdb-importer'); ?></h3>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 0%;"></div>
                    </div>
                    <div class="progress-stats">
                        <span id="progress-text">0 / 0</span>
                        <span id="progress-status"></span>
                    </div>
                    <div id="import-results"></div>
                </div>
            </div>
        </div>
        
        <style>
        .etmdb-bulk-container {
            max-width: 800px;
        }
        
        .bulk-method-content {
            margin-top: 15px;
        }
        
        .etmdb-progress-container {
            margin-top: 30px;
            padding: 20px;
            background: #fff;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #f0f0f0;
            border-radius: 10px;
            overflow: hidden;
            margin: 15px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: #0073aa;
            transition: width 0.3s ease;
        }
        
        .progress-stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        
        .import-result-item {
            padding: 8px 12px;
            margin: 5px 0;
            border-radius: 3px;
        }
        
        .import-result-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .import-result-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .import-result-skipped {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        </style>
        <?php
    }
    
    /**
     * Render import history page
     */
    public function render_history_page() {
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        
        $history = $this->import_processor->get_import_history($per_page, $offset);
        $stats = $this->import_processor->get_import_stats();
        
        ?>
        <div class="wrap">
            <h1><?php _e('Import History', 'enhanced-tmdb-importer'); ?></h1>
            
            <div class="etmdb-stats-container">
                <div class="etmdb-stats-grid">
                    <div class="etmdb-stat-item">
                        <div class="stat-number"><?php echo esc_html($stats->total_imports ?? 0); ?></div>
                        <div class="stat-label"><?php _e('Total Imports', 'enhanced-tmdb-importer'); ?></div>
                    </div>
                    <div class="etmdb-stat-item">
                        <div class="stat-number"><?php echo esc_html($stats->movies_imported ?? 0); ?></div>
                        <div class="stat-label"><?php _e('Movies', 'enhanced-tmdb-importer'); ?></div>
                    </div>
                    <div class="etmdb-stat-item">
                        <div class="stat-number"><?php echo esc_html($stats->tv_shows_imported ?? 0); ?></div>
                        <div class="stat-label"><?php _e('TV Shows', 'enhanced-tmdb-importer'); ?></div>
                    </div>
                    <div class="etmdb-stat-item">
                        <div class="stat-number"><?php echo esc_html($stats->imports_last_30_days ?? 0); ?></div>
                        <div class="stat-label"><?php _e('Last 30 Days', 'enhanced-tmdb-importer'); ?></div>
                    </div>
                </div>
            </div>
            
            <div class="etmdb-history-container">
                <h2><?php _e('Recent Imports', 'enhanced-tmdb-importer'); ?></h2>
                
                <?php if (empty($history)): ?>
                    <p><?php _e('No imports found.', 'enhanced-tmdb-importer'); ?></p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Title', 'enhanced-tmdb-importer'); ?></th>
                                <th><?php _e('Type', 'enhanced-tmdb-importer'); ?></th>
                                <th><?php _e('TMDB ID', 'enhanced-tmdb-importer'); ?></th>
                                <th><?php _e('Import Date', 'enhanced-tmdb-importer'); ?></th>
                                <th><?php _e('Status', 'enhanced-tmdb-importer'); ?></th>
                                <th><?php _e('Actions', 'enhanced-tmdb-importer'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $item): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($item->title); ?></strong>
                                    </td>
                                    <td>
                                        <span class="etmdb-type-badge etmdb-type-<?php echo esc_attr($item->content_type); ?>">
                                            <?php echo esc_html(ucfirst($item->content_type)); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html($item->tmdb_id); ?></td>
                                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($item->import_date))); ?></td>
                                    <td>
                                        <span class="status-<?php echo esc_attr($item->status); ?>">
                                            <?php echo esc_html(ucfirst($item->status)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($item->post_id && get_post($item->post_id)): ?>
                                            <a href="<?php echo esc_url(get_edit_post_link($item->post_id)); ?>" class="button button-small">
                                                <?php _e('Edit', 'enhanced-tmdb-importer'); ?>
                                            </a>
                                            <a href="<?php echo esc_url(get_permalink($item->post_id)); ?>" class="button button-small" target="_blank">
                                                <?php _e('View', 'enhanced-tmdb-importer'); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="description"><?php _e('Post not found', 'enhanced-tmdb-importer'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
        .etmdb-stats-container {
            margin-bottom: 30px;
        }
        
        .etmdb-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .etmdb-stat-item {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
            text-align: center;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 600;
            color: #0073aa;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        
        .etmdb-history-container {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        
        .status-completed {
            color: #46b450;
            font-weight: 600;
        }
        
        .status-failed {
            color: #dc3232;
            font-weight: 600;
        }
        </style>
        <?php
    }

    /**
     * Get pagination HTML
     */
    private function get_pagination($current_page, $total_pages, $base_url) {
        if ($total_pages <= 1) {
            return '';
        }

        $pagination = '<div class="etmdb-pagination">';

        // Previous button
        if ($current_page > 1) {
            $prev_url = add_query_arg('paged', $current_page - 1, $base_url);
            $pagination .= '<a href="' . esc_url($prev_url) . '" class="button">' . __('Previous', 'enhanced-tmdb-importer') . '</a>';
        }

        // Page numbers
        $start = max(1, $current_page - 2);
        $end = min($total_pages, $current_page + 2);

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $current_page) {
                $pagination .= '<button class="button current">' . $i . '</button>';
            } else {
                $page_url = add_query_arg('paged', $i, $base_url);
                $pagination .= '<a href="' . esc_url($page_url) . '" class="button">' . $i . '</a>';
            }
        }

        // Next button
        if ($current_page < $total_pages) {
            $next_url = add_query_arg('paged', $current_page + 1, $base_url);
            $pagination .= '<a href="' . esc_url($next_url) . '" class="button">' . __('Next', 'enhanced-tmdb-importer') . '</a>';
        }

        $pagination .= '</div>';

        return $pagination;
    }
}
