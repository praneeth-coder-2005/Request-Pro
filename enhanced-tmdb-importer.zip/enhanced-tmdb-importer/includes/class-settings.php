<?php
/**
 * Settings Class
 * 
 * Handles plugin settings and configuration
 */

if (!defined('ABSPATH')) {
    exit;
}

class ETMDB_Settings {
    
    private $option_name = 'etmdb_settings';
    private $tmdb_api;
    
    public function __construct() {
        $this->tmdb_api = new ETMDB_API();
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting(
            'etmdb_settings_group',
            $this->option_name,
            array($this, 'sanitize_settings')
        );
        
        // API Settings Section
        add_settings_section(
            'etmdb_api_section',
            __('API Configuration', 'enhanced-tmdb-importer'),
            array($this, 'api_section_callback'),
            'etmdb_settings'
        );
        
        add_settings_field(
            'tmdb_api_key',
            __('TMDB API Key', 'enhanced-tmdb-importer'),
            array($this, 'api_key_callback'),
            'etmdb_settings',
            'etmdb_api_section'
        );
        
        add_settings_field(
            'default_language',
            __('Default Language', 'enhanced-tmdb-importer'),
            array($this, 'language_callback'),
            'etmdb_settings',
            'etmdb_api_section'
        );
        
        // Import Settings Section
        add_settings_section(
            'etmdb_import_section',
            __('Import Settings', 'enhanced-tmdb-importer'),
            array($this, 'import_section_callback'),
            'etmdb_settings'
        );
        
        add_settings_field(
            'auto_set_featured_image',
            __('Auto Set Featured Image', 'enhanced-tmdb-importer'),
            array($this, 'featured_image_callback'),
            'etmdb_settings',
            'etmdb_import_section'
        );
        
        add_settings_field(
            'import_cast_crew',
            __('Import Cast & Crew', 'enhanced-tmdb-importer'),
            array($this, 'cast_crew_callback'),
            'etmdb_settings',
            'etmdb_import_section'
        );
        
        add_settings_field(
            'import_genres',
            __('Import Genres', 'enhanced-tmdb-importer'),
            array($this, 'genres_callback'),
            'etmdb_settings',
            'etmdb_import_section'
        );
        
        add_settings_field(
            'import_keywords',
            __('Import Keywords as Tags', 'enhanced-tmdb-importer'),
            array($this, 'keywords_callback'),
            'etmdb_settings',
            'etmdb_import_section'
        );
        
        add_settings_field(
            'batch_size',
            __('Bulk Import Batch Size', 'enhanced-tmdb-importer'),
            array($this, 'batch_size_callback'),
            'etmdb_settings',
            'etmdb_import_section'
        );
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (isset($_POST['test_connection'])) {
            $this->test_api_connection();
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Enhanced TMDB Importer Settings', 'enhanced-tmdb-importer'); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('etmdb_settings_group');
                do_settings_sections('etmdb_settings');
                submit_button();
                ?>
            </form>
            
            <div class="etmdb-test-connection">
                <h2><?php _e('Test API Connection', 'enhanced-tmdb-importer'); ?></h2>
                <form method="post">
                    <p>
                        <button type="submit" name="test_connection" class="button button-secondary">
                            <?php _e('Test TMDB Connection', 'enhanced-tmdb-importer'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
            <div class="etmdb-help-section">
                <h2><?php _e('Help & Documentation', 'enhanced-tmdb-importer'); ?></h2>
                
                <div class="etmdb-help-grid">
                    <div class="help-item">
                        <h3><?php _e('Getting TMDB API Key', 'enhanced-tmdb-importer'); ?></h3>
                        <p><?php _e('To use this plugin, you need a free API key from The Movie Database (TMDB):', 'enhanced-tmdb-importer'); ?></p>
                        <ol>
                            <li><?php _e('Visit', 'enhanced-tmdb-importer'); ?> <a href="https://www.themoviedb.org/account/signup" target="_blank">themoviedb.org</a> <?php _e('and create an account', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Go to your account settings and click on "API"', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Request an API key and fill out the required information', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Copy your API key and paste it in the field above', 'enhanced-tmdb-importer'); ?></li>
                        </ol>
                    </div>
                    
                    <div class="help-item">
                        <h3><?php _e('Import Process', 'enhanced-tmdb-importer'); ?></h3>
                        <p><?php _e('The import process works as follows:', 'enhanced-tmdb-importer'); ?></p>
                        <ul>
                            <li><?php _e('Search for movies/TV shows using the search interface', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Click "Import" on any result to add it to your site', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('The plugin will create a new post with all TMDB data', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Images, metadata, and taxonomies are automatically handled', 'enhanced-tmdb-importer'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="help-item">
                        <h3><?php _e('Bulk Import', 'enhanced-tmdb-importer'); ?></h3>
                        <p><?php _e('For importing multiple items:', 'enhanced-tmdb-importer'); ?></p>
                        <ul>
                            <li><?php _e('Use the Bulk Import page', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Enter TMDB IDs manually or upload a CSV file', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('Format: TMDB_ID,TYPE (e.g., 550,movie)', 'enhanced-tmdb-importer'); ?></li>
                            <li><?php _e('The system processes items in batches to avoid timeouts', 'enhanced-tmdb-importer'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .etmdb-test-connection {
            margin: 30px 0;
            padding: 20px;
            background: #fff;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        
        .etmdb-help-section {
            margin-top: 30px;
            padding: 20px;
            background: #fff;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        
        .etmdb-help-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .help-item {
            padding: 15px;
            background: #f9f9f9;
            border-radius: 5px;
        }
        
        .help-item h3 {
            margin-top: 0;
            color: #0073aa;
        }
        
        .help-item ul, .help-item ol {
            margin-left: 20px;
        }
        
        .help-item li {
            margin-bottom: 5px;
        }
        </style>
        <?php
    }
    
    /**
     * API section callback
     */
    public function api_section_callback() {
        echo '<p>' . __('Configure your TMDB API settings below.', 'enhanced-tmdb-importer') . '</p>';
    }
    
    /**
     * Import section callback
     */
    public function import_section_callback() {
        echo '<p>' . __('Configure how content should be imported from TMDB.', 'enhanced-tmdb-importer') . '</p>';
    }
    
    /**
     * API key field callback
     */
    public function api_key_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['tmdb_api_key']) ? $options['tmdb_api_key'] : '';
        
        echo '<input type="text" name="' . $this->option_name . '[tmdb_api_key]" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Enter your TMDB API key. Get one free at themoviedb.org', 'enhanced-tmdb-importer') . '</p>';
    }
    
    /**
     * Language field callback
     */
    public function language_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['default_language']) ? $options['default_language'] : 'en-US';
        
        $languages = array(
            'en-US' => 'English (US)',
            'en-GB' => 'English (UK)',
            'es-ES' => 'Spanish',
            'fr-FR' => 'French',
            'de-DE' => 'German',
            'it-IT' => 'Italian',
            'pt-BR' => 'Portuguese (Brazil)',
            'ja-JP' => 'Japanese',
            'ko-KR' => 'Korean',
            'zh-CN' => 'Chinese (Simplified)',
            'ru-RU' => 'Russian',
            'ar-SA' => 'Arabic',
            'hi-IN' => 'Hindi'
        );
        
        echo '<select name="' . $this->option_name . '[default_language]">';
        foreach ($languages as $code => $name) {
            echo '<option value="' . esc_attr($code) . '"' . selected($value, $code, false) . '>' . esc_html($name) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . __('Default language for TMDB API requests', 'enhanced-tmdb-importer') . '</p>';
    }
    
    /**
     * Featured image field callback
     */
    public function featured_image_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['auto_set_featured_image']) ? $options['auto_set_featured_image'] : true;
        
        echo '<input type="checkbox" name="' . $this->option_name . '[auto_set_featured_image]" value="1"' . checked($value, true, false) . ' />';
        echo '<label>' . __('Automatically set poster image as featured image', 'enhanced-tmdb-importer') . '</label>';
    }
    
    /**
     * Cast & crew field callback
     */
    public function cast_crew_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['import_cast_crew']) ? $options['import_cast_crew'] : true;
        
        echo '<input type="checkbox" name="' . $this->option_name . '[import_cast_crew]" value="1"' . checked($value, true, false) . ' />';
        echo '<label>' . __('Import cast and crew information', 'enhanced-tmdb-importer') . '</label>';
    }
    
    /**
     * Genres field callback
     */
    public function genres_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['import_genres']) ? $options['import_genres'] : true;
        
        echo '<input type="checkbox" name="' . $this->option_name . '[import_genres]" value="1"' . checked($value, true, false) . ' />';
        echo '<label>' . __('Import genres as categories', 'enhanced-tmdb-importer') . '</label>';
    }
    
    /**
     * Keywords field callback
     */
    public function keywords_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['import_keywords']) ? $options['import_keywords'] : false;
        
        echo '<input type="checkbox" name="' . $this->option_name . '[import_keywords]" value="1"' . checked($value, true, false) . ' />';
        echo '<label>' . __('Import keywords as post tags', 'enhanced-tmdb-importer') . '</label>';
    }
    
    /**
     * Batch size field callback
     */
    public function batch_size_callback() {
        $options = get_option($this->option_name, array());
        $value = isset($options['batch_size']) ? $options['batch_size'] : 5;
        
        echo '<input type="number" name="' . $this->option_name . '[batch_size]" value="' . esc_attr($value) . '" min="1" max="20" class="small-text" />';
        echo '<p class="description">' . __('Number of items to process in each bulk import batch (1-20)', 'enhanced-tmdb-importer') . '</p>';
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $sanitized = array();

        // TMDB API Settings
        if (isset($input['tmdb_api_key'])) {
            $sanitized['tmdb_api_key'] = sanitize_text_field($input['tmdb_api_key']);
        }

        if (isset($input['default_language'])) {
            $sanitized['default_language'] = sanitize_text_field($input['default_language']);
        }

        // Import Settings
        $sanitized['auto_set_featured_image'] = isset($input['auto_set_featured_image']);
        $sanitized['import_cast_crew'] = isset($input['import_cast_crew']);
        $sanitized['import_genres'] = isset($input['import_genres']);
        $sanitized['import_keywords'] = isset($input['import_keywords']);

        if (isset($input['batch_size'])) {
            $sanitized['batch_size'] = max(1, min(20, intval($input['batch_size'])));
        }



        return $sanitized;
    }



    /**
     * Test API connection
     */
    private function test_api_connection() {
        $test_result = $this->tmdb_api->test_connection();
        
        if ($test_result) {
            add_settings_error(
                'etmdb_settings',
                'api_test_success',
                __('TMDB API connection successful!', 'enhanced-tmdb-importer'),
                'success'
            );
        } else {
            add_settings_error(
                'etmdb_settings',
                'api_test_failed',
                __('TMDB API connection failed. Please check your API key.', 'enhanced-tmdb-importer'),
                'error'
            );
        }
    }
}
