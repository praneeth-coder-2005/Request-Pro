<?php
/**
 * TMDB API Handler Class
 * 
 * Handles all interactions with The Movie Database API
 */

if (!defined('ABSPATH')) {
    exit;
}

class ETMDB_API {
    
    private $api_key;
    private $base_url = 'https://api.themoviedb.org/3/';
    private $image_base_url = 'https://image.tmdb.org/t/p/';
    private $language;
    
    public function __construct() {
        $settings = get_option('etmdb_settings', array());
        
        // Try to get API key from our settings first, then fallback to idmuvi settings
        $this->api_key = !empty($settings['tmdb_api_key']) ? $settings['tmdb_api_key'] : $this->get_idmuvi_api_key();
        $this->language = !empty($settings['default_language']) ? $settings['default_language'] : 'en-US';
    }
    
    /**
     * Get API key from idmuvi-core settings as fallback
     */
    private function get_idmuvi_api_key() {
        $idmuv_tmdb = get_option('idmuv_tmdb');
        return !empty($idmuv_tmdb['tmdb_api']) ? $idmuv_tmdb['tmdb_api'] : '';
    }
    
    /**
     * Make API request
     */
    private function make_request($endpoint, $params = array()) {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('TMDB API key is not configured', 'enhanced-tmdb-importer'));
        }
        
        $default_params = array(
            'api_key' => $this->api_key,
            'language' => $this->language
        );
        
        $params = array_merge($default_params, $params);
        $url = $this->base_url . $endpoint . '?' . http_build_query($params);
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (wp_remote_retrieve_response_code($response) !== 200) {
            return new WP_Error('api_error', $data['status_message'] ?? __('API request failed', 'enhanced-tmdb-importer'));
        }
        
        return $data;
    }
    
    /**
     * Search for movies or TV shows
     */
    public function search($query, $type = 'multi', $page = 1) {
        $endpoint = $type === 'multi' ? 'search/multi' : "search/{$type}";
        
        $params = array(
            'query' => $query,
            'page' => $page,
            'include_adult' => false
        );
        
        $response = $this->make_request($endpoint, $params);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Filter and format results
        $formatted_results = array();
        
        if (!empty($response['results'])) {
            foreach ($response['results'] as $item) {
                // Skip person results in multi search
                if ($type === 'multi' && $item['media_type'] === 'person') {
                    continue;
                }
                
                $formatted_item = $this->format_search_result($item, $type);
                if ($formatted_item) {
                    $formatted_results[] = $formatted_item;
                }
            }
        }
        
        return array(
            'results' => $formatted_results,
            'total_pages' => $response['total_pages'] ?? 1,
            'total_results' => $response['total_results'] ?? 0,
            'page' => $response['page'] ?? 1
        );
    }
    
    /**
     * Format search result item
     */
    private function format_search_result($item, $search_type) {
        $type = $search_type === 'multi' ? $item['media_type'] : $search_type;
        
        if (!in_array($type, array('movie', 'tv'))) {
            return null;
        }
        
        $title = $type === 'movie' ? ($item['title'] ?? '') : ($item['name'] ?? '');
        $release_date = $type === 'movie' ? ($item['release_date'] ?? '') : ($item['first_air_date'] ?? '');
        $year = $release_date ? date('Y', strtotime($release_date)) : '';
        
        return array(
            'id' => $item['id'],
            'type' => $type,
            'title' => $title,
            'original_title' => $type === 'movie' ? ($item['original_title'] ?? '') : ($item['original_name'] ?? ''),
            'overview' => $item['overview'] ?? '',
            'poster_path' => $item['poster_path'] ? $this->get_image_url($item['poster_path'], 'w300') : '',
            'backdrop_path' => $item['backdrop_path'] ? $this->get_image_url($item['backdrop_path'], 'w780') : '',
            'release_date' => $release_date,
            'year' => $year,
            'vote_average' => $item['vote_average'] ?? 0,
            'vote_count' => $item['vote_count'] ?? 0,
            'popularity' => $item['popularity'] ?? 0,
            'genre_ids' => $item['genre_ids'] ?? array(),
            'adult' => $item['adult'] ?? false
        );
    }
    
    /**
     * Get detailed information for a movie
     */
    public function get_movie_details($movie_id) {
        $endpoint = "movie/{$movie_id}";
        $params = array(
            'append_to_response' => 'videos,keywords,images,credits,release_dates'
        );
        
        $response = $this->make_request($endpoint, $params);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return $this->format_movie_details($response);
    }
    
    /**
     * Get detailed information for a TV show
     */
    public function get_tv_details($tv_id) {
        $endpoint = "tv/{$tv_id}";
        $params = array(
            'append_to_response' => 'videos,keywords,images,credits,content_ratings'
        );
        
        $response = $this->make_request($endpoint, $params);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return $this->format_tv_details($response);
    }
    
    /**
     * Format movie details
     */
    private function format_movie_details($data) {
        $genres = array();
        if (!empty($data['genres'])) {
            foreach ($data['genres'] as $genre) {
                $genres[] = $genre['name'];
            }
        }
        
        $countries = array();
        if (!empty($data['production_countries'])) {
            foreach ($data['production_countries'] as $country) {
                $countries[] = $country['name'];
            }
        }
        
        $cast = array();
        $crew = array();
        if (!empty($data['credits'])) {
            if (!empty($data['credits']['cast'])) {
                foreach (array_slice($data['credits']['cast'], 0, 10) as $person) {
                    $cast[] = array(
                        'name' => $person['name'],
                        'character' => $person['character'] ?? '',
                        'profile_path' => $person['profile_path'] ? $this->get_image_url($person['profile_path'], 'w185') : ''
                    );
                }
            }
            
            if (!empty($data['credits']['crew'])) {
                foreach ($data['credits']['crew'] as $person) {
                    if (in_array($person['job'], array('Director', 'Producer', 'Writer', 'Screenplay'))) {
                        $crew[] = array(
                            'name' => $person['name'],
                            'job' => $person['job'],
                            'department' => $person['department'] ?? ''
                        );
                    }
                }
            }
        }
        
        $trailer_url = '';
        if (!empty($data['videos']['results'])) {
            foreach ($data['videos']['results'] as $video) {
                if ($video['type'] === 'Trailer' && $video['site'] === 'YouTube') {
                    $trailer_url = 'https://www.youtube.com/watch?v=' . $video['key'];
                    break;
                }
            }
        }
        
        // Get certification/rating
        $rating = '';
        if (!empty($data['release_dates']['results'])) {
            foreach ($data['release_dates']['results'] as $release) {
                if ($release['iso_3166_1'] === 'US' && !empty($release['release_dates'])) {
                    $rating = $release['release_dates'][0]['certification'] ?? '';
                    break;
                }
            }
        }
        
        return array(
            'id' => $data['id'],
            'type' => 'movie',
            'title' => $data['title'] ?? '',
            'original_title' => $data['original_title'] ?? '',
            'overview' => $data['overview'] ?? '',
            'tagline' => $data['tagline'] ?? '',
            'poster_path' => $data['poster_path'] ? $this->get_image_url($data['poster_path'], 'w500') : '',
            'backdrop_path' => $data['backdrop_path'] ? $this->get_image_url($data['backdrop_path'], 'original') : '',
            'release_date' => $data['release_date'] ?? '',
            'runtime' => $data['runtime'] ?? 0,
            'vote_average' => $data['vote_average'] ?? 0,
            'vote_count' => $data['vote_count'] ?? 0,
            'popularity' => $data['popularity'] ?? 0,
            'budget' => $data['budget'] ?? 0,
            'revenue' => $data['revenue'] ?? 0,
            'genres' => $genres,
            'countries' => $countries,
            'original_language' => $data['original_language'] ?? '',
            'adult' => $data['adult'] ?? false,
            'status' => $data['status'] ?? '',
            'cast' => $cast,
            'crew' => $crew,
            'trailer_url' => $trailer_url,
            'rating' => $rating,
            'keywords' => $this->extract_keywords($data['keywords'] ?? array()),
            'images' => $this->extract_images($data['images'] ?? array())
        );
    }
    
    /**
     * Format TV show details
     */
    private function format_tv_details($data) {
        $genres = array();
        if (!empty($data['genres'])) {
            foreach ($data['genres'] as $genre) {
                $genres[] = $genre['name'];
            }
        }
        
        $networks = array();
        if (!empty($data['networks'])) {
            foreach ($data['networks'] as $network) {
                $networks[] = $network['name'];
            }
        }
        
        $countries = array();
        if (!empty($data['origin_country'])) {
            $countries = $data['origin_country'];
        }
        
        $cast = array();
        $crew = array();
        if (!empty($data['credits'])) {
            if (!empty($data['credits']['cast'])) {
                foreach (array_slice($data['credits']['cast'], 0, 10) as $person) {
                    $cast[] = array(
                        'name' => $person['name'],
                        'character' => $person['character'] ?? '',
                        'profile_path' => $person['profile_path'] ? $this->get_image_url($person['profile_path'], 'w185') : ''
                    );
                }
            }
            
            if (!empty($data['credits']['crew'])) {
                foreach ($data['credits']['crew'] as $person) {
                    if (in_array($person['job'], array('Executive Producer', 'Producer', 'Creator', 'Writer'))) {
                        $crew[] = array(
                            'name' => $person['name'],
                            'job' => $person['job'],
                            'department' => $person['department'] ?? ''
                        );
                    }
                }
            }
        }
        
        $trailer_url = '';
        if (!empty($data['videos']['results'])) {
            foreach ($data['videos']['results'] as $video) {
                if ($video['type'] === 'Trailer' && $video['site'] === 'YouTube') {
                    $trailer_url = 'https://www.youtube.com/watch?v=' . $video['key'];
                    break;
                }
            }
        }
        
        // Get content rating
        $rating = '';
        if (!empty($data['content_ratings']['results'])) {
            foreach ($data['content_ratings']['results'] as $content_rating) {
                if ($content_rating['iso_3166_1'] === 'US') {
                    $rating = $content_rating['rating'] ?? '';
                    break;
                }
            }
        }
        
        return array(
            'id' => $data['id'],
            'type' => 'tv',
            'title' => $data['name'] ?? '',
            'original_title' => $data['original_name'] ?? '',
            'overview' => $data['overview'] ?? '',
            'tagline' => $data['tagline'] ?? '',
            'poster_path' => $data['poster_path'] ? $this->get_image_url($data['poster_path'], 'w500') : '',
            'backdrop_path' => $data['backdrop_path'] ? $this->get_image_url($data['backdrop_path'], 'original') : '',
            'first_air_date' => $data['first_air_date'] ?? '',
            'last_air_date' => $data['last_air_date'] ?? '',
            'number_of_episodes' => $data['number_of_episodes'] ?? 0,
            'number_of_seasons' => $data['number_of_seasons'] ?? 0,
            'episode_run_time' => !empty($data['episode_run_time']) ? $data['episode_run_time'][0] : 0,
            'vote_average' => $data['vote_average'] ?? 0,
            'vote_count' => $data['vote_count'] ?? 0,
            'popularity' => $data['popularity'] ?? 0,
            'genres' => $genres,
            'networks' => $networks,
            'countries' => $countries,
            'original_language' => $data['original_language'] ?? '',
            'adult' => $data['adult'] ?? false,
            'status' => $data['status'] ?? '',
            'cast' => $cast,
            'crew' => $crew,
            'trailer_url' => $trailer_url,
            'rating' => $rating,
            'keywords' => $this->extract_keywords($data['keywords'] ?? array()),
            'images' => $this->extract_images($data['images'] ?? array())
        );
    }
    
    /**
     * Extract keywords from API response
     */
    private function extract_keywords($keywords_data) {
        $keywords = array();
        
        if (!empty($keywords_data['keywords'])) {
            foreach ($keywords_data['keywords'] as $keyword) {
                $keywords[] = $keyword['name'];
            }
        } elseif (!empty($keywords_data['results'])) {
            foreach ($keywords_data['results'] as $keyword) {
                $keywords[] = $keyword['name'];
            }
        }
        
        return $keywords;
    }
    
    /**
     * Extract images from API response
     */
    private function extract_images($images_data) {
        $images = array(
            'backdrops' => array(),
            'posters' => array()
        );
        
        if (!empty($images_data['backdrops'])) {
            foreach (array_slice($images_data['backdrops'], 0, 5) as $image) {
                $images['backdrops'][] = $this->get_image_url($image['file_path'], 'original');
            }
        }
        
        if (!empty($images_data['posters'])) {
            foreach (array_slice($images_data['posters'], 0, 5) as $image) {
                $images['posters'][] = $this->get_image_url($image['file_path'], 'w500');
            }
        }
        
        return $images;
    }
    
    /**
     * Get full image URL
     */
    public function get_image_url($path, $size = 'original') {
        if (empty($path)) {
            return '';
        }
        
        return $this->image_base_url . $size . $path;
    }
    
    /**
     * Get available image sizes
     */
    public function get_image_sizes() {
        return array(
            'poster' => array('w92', 'w154', 'w185', 'w342', 'w500', 'w780', 'original'),
            'backdrop' => array('w300', 'w780', 'w1280', 'original'),
            'profile' => array('w45', 'w185', 'h632', 'original')
        );
    }
    
    /**
     * Test API connection
     */
    public function test_connection() {
        $response = $this->make_request('configuration');
        return !is_wp_error($response);
    }
}
