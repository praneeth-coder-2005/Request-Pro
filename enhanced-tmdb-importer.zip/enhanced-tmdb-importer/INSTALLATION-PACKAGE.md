# 📦 Enhanced TMDB Importer - Installation Package

## 🎯 **How to Create Plugin ZIP for Another WordPress Site**

### **Method 1: Manual ZIP Creation (Recommended)**

1. **Navigate to your WordPress plugins folder:**
   ```
   wp-content/plugins/
   ```

2. **Find the `enhanced-tmdb-importer` folder**

3. **Right-click on the folder** and select:
   - **Windows**: "Send to" → "Compressed (zipped) folder"
   - **Mac**: "Compress enhanced-tmdb-importer"
   - **Linux**: "Create Archive" or use terminal: `zip -r enhanced-tmdb-importer.zip enhanced-tmdb-importer/`

4. **You'll get**: `enhanced-tmdb-importer.zip`

### **Method 2: Using File Manager (cPanel/Hosting)**

1. **Login to your hosting cPanel**
2. **Open File Manager**
3. **Navigate to**: `public_html/wp-content/plugins/`
4. **Right-click** on `enhanced-tmdb-importer` folder
5. **Select "Compress"** → **ZIP format**
6. **Download** the created ZIP file

### **Method 3: Using FTP Client**

1. **Connect via FTP** to your site
2. **Navigate to**: `/wp-content/plugins/`
3. **Download** the entire `enhanced-tmdb-importer` folder
4. **ZIP it locally** on your computer

## 📁 **What's Included in the Package**

```
enhanced-tmdb-importer/
├── enhanced-tmdb-importer.php     (Main plugin file)
├── README.md                      (Documentation)
├── INSTALLATION.md               (Installation guide)
├── INSTALLATION-PACKAGE.md       (This file)
├── includes/
│   ├── class-admin-interface.php
│   ├── class-import-processor.php
│   ├── class-settings.php
│   └── class-tmdb-api.php
└── assets/
    ├── css/
    └── js/
```

## 🚀 **Installation on New WordPress Site**

### **Step 1: Upload Plugin**

**Option A: WordPress Admin (Recommended)**
1. **Login** to your WordPress admin
2. **Go to**: Plugins → Add New
3. **Click**: "Upload Plugin"
4. **Choose**: `enhanced-tmdb-importer.zip`
5. **Click**: "Install Now"
6. **Activate** the plugin

**Option B: FTP Upload**
1. **Extract** the ZIP file
2. **Upload** the `enhanced-tmdb-importer` folder to `/wp-content/plugins/`
3. **Go to**: WordPress Admin → Plugins
4. **Activate**: "Enhanced TMDB Importer"

**Option C: File Manager**
1. **Login** to cPanel/hosting panel
2. **Open** File Manager
3. **Navigate to**: `public_html/wp-content/plugins/`
4. **Upload** and extract the ZIP file
5. **Activate** in WordPress admin

### **Step 2: Get TMDB API Key**
1. **Visit**: [themoviedb.org](https://www.themoviedb.org/account/signup)
2. **Create account** (free)
3. **Go to**: Account Settings → API
4. **Request API key** (fill out the form)
5. **Copy** your API key

### **Step 3: Configure Plugin**
1. **Go to**: WordPress Admin → TMDB Importer → Settings
2. **Paste** your TMDB API key
3. **Configure settings**:
   - ✅ Auto set featured image
   - ✅ Import cast & crew
   - ✅ Import genres
   - ⚪ Import keywords (optional)
   - Batch size: 5
4. **Save settings**
5. **Test connection**

### **Step 4: Start Using**
1. **Go to**: TMDB Importer → Search & Import
2. **Search** for movies/TV shows
3. **Import** content with one click!

## ⚙️ **System Requirements**

- **WordPress**: 5.0 or higher
- **PHP**: 7.4 or higher
- **MySQL**: 5.6 or higher
- **Memory**: 128MB minimum (256MB recommended)
- **TMDB API Key**: Free from themoviedb.org

## 🎯 **Compatible With**

- ✅ **MuviPro Theme**
- ✅ **IDMuvi Core Plugin**
- ✅ **Most Movie/Entertainment Themes**
- ✅ **Custom Post Types**
- ✅ **Multisite WordPress**

## 🔧 **Post-Installation Setup**

### **For Movie Sites:**
1. **Ensure** you have movie post types (IDMuvi Core or similar)
2. **Configure** permalink structure
3. **Set up** categories/genres
4. **Test import** with one movie first

### **For TV Show Sites:**
1. **Check** TV show post types exist
2. **Configure** season/episode structure
3. **Set up** show categories
4. **Test import** with one show

## 💡 **Pro Tips**

### **Before Mass Import:**
- **Backup** your database
- **Test** with 1-2 items first
- **Check** server resources
- **Verify** API key works

### **For Best Performance:**
- **Use** smaller batch sizes (3-5 items)
- **Import** during low-traffic hours
- **Monitor** server resources
- **Clear** caches after import

### **Troubleshooting:**
- **Check** error logs if imports fail
- **Verify** TMDB API key is valid
- **Ensure** proper file permissions
- **Test** with different movies/shows

## 📞 **Support & Updates**

### **Getting Help:**
1. **Check** the README.md file
2. **Review** settings configuration
3. **Test** API connection
4. **Check** WordPress error logs

### **Common Issues:**
- **API Key Invalid**: Get new key from TMDB
- **Import Fails**: Check server memory/timeout
- **Images Not Loading**: Verify file permissions
- **Slow Performance**: Reduce batch size

## 🎉 **You're Ready!**

Once installed and configured, you'll have:
- ✅ **Professional TMDB importer**
- ✅ **Search and import functionality**
- ✅ **Bulk import capabilities**
- ✅ **Automatic image downloads**
- ✅ **Complete metadata import**
- ✅ **Clean, simple interface**

**Happy importing!** 🎬✨

---

**Package Version**: 1.0.0  
**Last Updated**: 2025  
**Compatibility**: WordPress 5.0+
