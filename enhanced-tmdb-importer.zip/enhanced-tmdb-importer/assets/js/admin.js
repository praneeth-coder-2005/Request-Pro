jQuery(document).ready(function($) {
    
    // Search functionality
    $('#etmdb-search-form').on('submit', function(e) {
        e.preventDefault();
        
        const query = $('#search-query').val().trim();
        const type = $('#search-type').val();
        
        if (!query) {
            alert(etmdb_ajax.strings.error + ': Please enter a search query');
            return;
        }
        
        performSearch(query, type, 1);
    });
    
    // Perform TMDB search
    function performSearch(query, type, page) {
        const $resultsContainer = $('#etmdb-search-results');
        const $resultsContent = $('#search-results-content');
        const $searchBtn = $('#search-btn');
        
        // Show loading state
        $searchBtn.prop('disabled', true).text(etmdb_ajax.strings.searching);
        $resultsContainer.show();
        $resultsContent.html('<div class="etmdb-loading">Searching TMDB...</div>');
        
        $.ajax({
            url: etmdb_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'etmdb_search',
                nonce: etmdb_ajax.nonce,
                query: query,
                type: type,
                page: page
            },
            success: function(response) {
                if (response.success) {
                    displaySearchResults(response.data, page);
                } else {
                    $resultsContent.html('<div class="etmdb-no-results">Search failed: ' + (response.data || 'Unknown error') + '</div>');
                }
            },
            error: function() {
                $resultsContent.html('<div class="etmdb-no-results">Search request failed. Please try again.</div>');
            },
            complete: function() {
                $searchBtn.prop('disabled', false).text('Search TMDB');
            }
        });
    }
    
    // Display search results
    function displaySearchResults(data, currentPage) {
        const $resultsContent = $('#search-results-content');
        const $pagination = $('#search-pagination');
        
        if (!data.results || data.results.length === 0) {
            $resultsContent.html('<div class="etmdb-no-results">No results found. Try a different search term.</div>');
            $pagination.empty();
            return;
        }
        
        let html = '';
        
        data.results.forEach(function(item) {
            const posterImg = item.poster_path ? 
                `<img src="${item.poster_path}" alt="${item.title}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iMTIwIiB2aWV3Qm94PSIwIDAgODAgMTIwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSI4MCIgaGVpZ2h0PSIxMjAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI0MCIgeT0iNjAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiM5OTkiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxMiI+Tm8gSW1hZ2U8L3RleHQ+PC9zdmc+'" />` :
                '<div style="width: 80px; height: 120px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">No Image</div>';
            
            const overview = item.overview ? 
                (item.overview.length > 200 ? item.overview.substring(0, 200) + '...' : item.overview) : 
                'No description available.';
            
            const typeClass = item.type === 'movie' ? 'etmdb-type-movie' : 'etmdb-type-tv';
            const typeLabel = item.type === 'movie' ? 'Movie' : 'TV Show';
            
            html += `
                <div class="etmdb-result-item" data-tmdb-id="${item.id}" data-type="${item.type}">
                    <div class="etmdb-result-poster">
                        ${posterImg}
                    </div>
                    <div class="etmdb-result-info">
                        <h3 class="etmdb-result-title">${item.title}</h3>
                        <div class="etmdb-result-meta">
                            <span class="etmdb-type-badge ${typeClass}">${typeLabel}</span>
                            ${item.year ? `<span class="etmdb-year">${item.year}</span>` : ''}
                            ${item.vote_average > 0 ? `<span class="etmdb-rating">${item.vote_average.toFixed(1)}</span>` : ''}
                        </div>
                        <div class="etmdb-result-overview">${overview}</div>
                    </div>
                    <div class="etmdb-result-actions">
                        <button class="etmdb-import-btn" onclick="importItem(${item.id}, '${item.type}', '${item.title.replace(/'/g, "\\'")}')">
                            Import
                        </button>
                    </div>
                </div>
            `;
        });
        
        $resultsContent.html(html);
        
        // Generate pagination
        if (data.total_pages > 1) {
            generatePagination(data.page, data.total_pages, $pagination);
        } else {
            $pagination.empty();
        }
    }
    
    // Generate pagination controls
    function generatePagination(currentPage, totalPages, $container) {
        let html = '<div class="etmdb-pagination">';
        
        // Previous button
        if (currentPage > 1) {
            html += `<button onclick="searchPage(${currentPage - 1})">Previous</button>`;
        }
        
        // Page numbers
        const start = Math.max(1, currentPage - 2);
        const end = Math.min(totalPages, currentPage + 2);
        
        for (let i = start; i <= end; i++) {
            if (i === currentPage) {
                html += `<button class="current">${i}</button>`;
            } else {
                html += `<button onclick="searchPage(${i})">${i}</button>`;
            }
        }
        
        // Next button
        if (currentPage < totalPages) {
            html += `<button onclick="searchPage(${currentPage + 1})">Next</button>`;
        }
        
        html += '</div>';
        $container.html(html);
    }
    
    // Search specific page
    window.searchPage = function(page) {
        const query = $('#search-query').val().trim();
        const type = $('#search-type').val();
        performSearch(query, type, page);
    };
    
    // Import single item
    window.importItem = function(tmdbId, type, title) {
        if (!confirm(etmdb_ajax.strings.confirm_import)) {
            return;
        }
        
        const $btn = $(`.etmdb-result-item[data-tmdb-id="${tmdbId}"] .etmdb-import-btn`);
        const originalText = $btn.text();
        
        $btn.prop('disabled', true).text(etmdb_ajax.strings.importing);
        
        $.ajax({
            url: etmdb_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'etmdb_import',
                nonce: etmdb_ajax.nonce,
                tmdb_id: tmdbId,
                type: type
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data.message);
                    $btn.text('Imported').addClass('imported');
                    
                    // Add edit link if available
                    if (response.data.edit_url) {
                        $btn.after(`<a href="${response.data.edit_url}" class="button button-small" target="_blank">Edit</a>`);
                    }
                } else {
                    showNotice('error', response.data.message || 'Import failed');
                    $btn.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                showNotice('error', 'Import request failed');
                $btn.prop('disabled', false).text(originalText);
            }
        });
    };
    
    // Bulk import functionality
    $('#bulk-method').on('change', function() {
        const method = $(this).val();
        $('.bulk-method-content').hide();
        $(`#${method}-entry`).show();
    });
    
    $('#etmdb-bulk-form').on('submit', function(e) {
        e.preventDefault();
        
        const method = $('#bulk-method').val();
        let items = [];
        
        if (method === 'manual') {
            const idsText = $('#bulk-ids').val().trim();
            if (!idsText) {
                alert('Please enter TMDB IDs');
                return;
            }
            
            const lines = idsText.split('\n');
            lines.forEach(function(line) {
                line = line.trim();
                if (line) {
                    const parts = line.split(',');
                    if (parts.length >= 2) {
                        items.push({
                            tmdb_id: parseInt(parts[0].trim()),
                            type: parts[1].trim(),
                            title: parts[2] ? parts[2].trim() : `Item ${parts[0]}`
                        });
                    }
                }
            });
        } else if (method === 'csv') {
            // CSV handling would go here
            alert('CSV import not yet implemented in this demo');
            return;
        }
        
        if (items.length === 0) {
            alert('No valid items to import');
            return;
        }
        
        startBulkImport(items);
    });
    
    // Start bulk import process
    function startBulkImport(items) {
        const $form = $('#etmdb-bulk-form');
        const $progress = $('#etmdb-bulk-progress');
        const $progressFill = $('.progress-fill');
        const $progressText = $('#progress-text');
        const $progressStatus = $('#progress-status');
        const $results = $('#import-results');
        
        $form.hide();
        $progress.show();
        $results.empty();
        
        let processed = 0;
        const total = items.length;
        
        $progressText.text(`${processed} / ${total}`);
        $progressStatus.text('Starting import...');
        
        // Process items in batches
        processBatch(items, 0, processed, total, $progressFill, $progressText, $progressStatus, $results);
    }
    
    // Process batch of items
    function processBatch(items, startIndex, processed, total, $progressFill, $progressText, $progressStatus, $results) {
        const batchSize = 5; // Process 5 items at a time
        const batch = items.slice(startIndex, startIndex + batchSize);
        
        if (batch.length === 0) {
            // All done
            $progressStatus.text('Import completed!');
            return;
        }
        
        $progressStatus.text('Processing batch...');
        
        $.ajax({
            url: etmdb_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'etmdb_bulk_import',
                nonce: etmdb_ajax.nonce,
                items: JSON.stringify(batch)
            },
            success: function(response) {
                if (response.success) {
                    const results = response.data;
                    processed += batch.length;
                    
                    // Update progress
                    const percentage = (processed / total) * 100;
                    $progressFill.css('width', percentage + '%');
                    $progressText.text(`${processed} / ${total}`);
                    
                    // Display results
                    results.details.forEach(function(result) {
                        const statusClass = result.status === 'success' ? 'import-result-success' : 
                                          result.status === 'skipped' ? 'import-result-skipped' : 'import-result-error';
                        
                        $results.append(`
                            <div class="import-result-item ${statusClass}">
                                <strong>${result.title}</strong>: ${result.message}
                            </div>
                        `);
                    });
                    
                    // Process next batch
                    if (processed < total) {
                        setTimeout(function() {
                            processBatch(items, startIndex + batchSize, processed, total, $progressFill, $progressText, $progressStatus, $results);
                        }, 1000); // Small delay between batches
                    } else {
                        $progressStatus.text(`Import completed! Success: ${results.success}, Failed: ${results.failed}, Skipped: ${results.skipped}`);
                    }
                } else {
                    $progressStatus.text('Batch processing failed');
                }
            },
            error: function() {
                $progressStatus.text('Batch processing error');
            }
        });
    }
    
    // Show admin notice
    function showNotice(type, message) {
        const $notice = $('#etmdb-import-status');
        $notice.removeClass('notice-success notice-error notice-warning')
               .addClass(`notice-${type}`)
               .html(`<p>${message}</p>`)
               .show();
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $notice.fadeOut();
        }, 5000);
    }
    
});
