<?php
/**
 * Plugin Name: Enhanced TMDB Importer
 * Plugin URI: https://github.com/your-username/enhanced-tmdb-importer
 * Description: A comprehensive TMDB importer for WordPress movie sites with search functionality, bulk import, and seamless integration with MuviPro theme.
 * Version: 1.0.0
 * Author: Enhanced TMDB Team
 * License: GPL v2 or later
 * Text Domain: enhanced-tmdb-importer
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ETMDB_VERSION', '1.0.0');
define('ETMDB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ETMDB_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ETMDB_PLUGIN_FILE', __FILE__);

/**
 * Main Enhanced TMDB Importer Class
 */
class Enhanced_TMDB_Importer {
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_etmdb_search', array($this, 'ajax_search'));
        add_action('wp_ajax_etmdb_import', array($this, 'ajax_import'));
        add_action('wp_ajax_etmdb_bulk_import', array($this, 'ajax_bulk_import'));
        
        // Activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once ETMDB_PLUGIN_DIR . 'includes/class-tmdb-api.php';
        require_once ETMDB_PLUGIN_DIR . 'includes/class-import-processor.php';
        require_once ETMDB_PLUGIN_DIR . 'includes/class-admin-interface.php';
        require_once ETMDB_PLUGIN_DIR . 'includes/class-settings.php';
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain
        load_plugin_textdomain('enhanced-tmdb-importer', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Check if idmuvi-core is active
        if (!$this->is_idmuvi_core_active()) {
            add_action('admin_notices', array($this, 'idmuvi_core_missing_notice'));
            return;
        }

        // Check theme compatibility (optional warning)
        if (!$this->is_muvipro_theme_active()) {
            add_action('admin_notices', array($this, 'theme_compatibility_notice'));
        }
        
        // Initialize components
        $this->tmdb_api = new ETMDB_API();
        $this->import_processor = new ETMDB_Import_Processor();
        $this->admin_interface = new ETMDB_Admin_Interface();
        $this->settings = new ETMDB_Settings();
    }
    
    /**
     * Check if idmuvi-core plugin is active
     */
    private function is_idmuvi_core_active() {
        // Check if plugin is active
        if (function_exists('is_plugin_active')) {
            return is_plugin_active('idmuvi-core/idmuvi-core.php');
        }

        // Fallback: check if main class exists
        return class_exists('Idmuvi_Core_Init');
    }
    
    /**
     * Check if MuviPro theme is active
     */
    private function is_muvipro_theme_active() {
        $theme = wp_get_theme();
        return (strtolower($theme->get('Name')) === 'muvipro' ||
                strtolower($theme->get_template()) === 'muvipro');
    }

    /**
     * Show notice if idmuvi-core is missing
     */
    public function idmuvi_core_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Enhanced TMDB Importer requires the IDMuvi Core plugin to be active.', 'enhanced-tmdb-importer'); ?></p>
        </div>
        <?php
    }

    /**
     * Show theme compatibility notice
     */
    public function theme_compatibility_notice() {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p><?php _e('Enhanced TMDB Importer is designed for the MuviPro theme. Some features may not work optimally with other themes.', 'enhanced-tmdb-importer'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('TMDB Importer', 'enhanced-tmdb-importer'),
            __('TMDB Importer', 'enhanced-tmdb-importer'),
            'manage_options',
            'enhanced-tmdb-importer',
            array($this->admin_interface, 'render_main_page'),
            'dashicons-download',
            30
        );
        
        add_submenu_page(
            'enhanced-tmdb-importer',
            __('Search & Import', 'enhanced-tmdb-importer'),
            __('Search & Import', 'enhanced-tmdb-importer'),
            'manage_options',
            'enhanced-tmdb-importer',
            array($this->admin_interface, 'render_main_page')
        );
        
        add_submenu_page(
            'enhanced-tmdb-importer',
            __('Bulk Import', 'enhanced-tmdb-importer'),
            __('Bulk Import', 'enhanced-tmdb-importer'),
            'manage_options',
            'etmdb-bulk-import',
            array($this->admin_interface, 'render_bulk_import_page')
        );
        
        add_submenu_page(
            'enhanced-tmdb-importer',
            __('Import History', 'enhanced-tmdb-importer'),
            __('Import History', 'enhanced-tmdb-importer'),
            'manage_options',
            'etmdb-import-history',
            array($this->admin_interface, 'render_history_page')
        );
        
        add_submenu_page(
            'enhanced-tmdb-importer',
            __('Settings', 'enhanced-tmdb-importer'),
            __('Settings', 'enhanced-tmdb-importer'),
            'manage_options',
            'etmdb-settings',
            array($this->settings, 'render_settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'enhanced-tmdb-importer') === false && strpos($hook, 'etmdb-') === false) {
            return;
        }
        
        wp_enqueue_script(
            'etmdb-admin-js',
            ETMDB_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            ETMDB_VERSION,
            true
        );
        
        wp_enqueue_style(
            'etmdb-admin-css',
            ETMDB_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            ETMDB_VERSION
        );
        
        wp_localize_script('etmdb-admin-js', 'etmdb_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('etmdb_nonce'),
            'strings' => array(
                'searching' => __('Searching...', 'enhanced-tmdb-importer'),
                'importing' => __('Importing...', 'enhanced-tmdb-importer'),
                'success' => __('Success!', 'enhanced-tmdb-importer'),
                'error' => __('Error occurred', 'enhanced-tmdb-importer'),
                'confirm_import' => __('Are you sure you want to import this item?', 'enhanced-tmdb-importer'),
            )
        ));
    }
    
    /**
     * AJAX search handler
     */
    public function ajax_search() {
        check_ajax_referer('etmdb_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'enhanced-tmdb-importer'));
        }
        
        $query = sanitize_text_field($_POST['query']);
        $type = sanitize_text_field($_POST['type']); // 'movie' or 'tv'
        
        $results = $this->tmdb_api->search($query, $type);
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX import handler
     */
    public function ajax_import() {
        check_ajax_referer('etmdb_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'enhanced-tmdb-importer'));
        }
        
        $tmdb_id = intval($_POST['tmdb_id']);
        $type = sanitize_text_field($_POST['type']);
        
        $result = $this->import_processor->import_single($tmdb_id, $type);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX bulk import handler
     */
    public function ajax_bulk_import() {
        check_ajax_referer('etmdb_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'enhanced-tmdb-importer'));
        }
        
        $items = json_decode(stripslashes($_POST['items']), true);
        
        $result = $this->import_processor->bulk_import($items);
        
        wp_send_json_success($result);
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create import history table
        $this->create_import_history_table();
        
        // Set default options
        $default_options = array(
            'tmdb_api_key' => '',
            'default_language' => 'en-US',
            'auto_set_featured_image' => true,
            'import_cast_crew' => true,
            'import_genres' => true,
            'import_keywords' => false,
            'batch_size' => 5,
        );
        
        add_option('etmdb_settings', $default_options);
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up scheduled events if any
        wp_clear_scheduled_hook('etmdb_cleanup_temp_files');
    }
    
    /**
     * Create import history table
     */
    private function create_import_history_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'etmdb_import_history';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            tmdb_id int(11) NOT NULL,
            post_id bigint(20) NOT NULL,
            content_type varchar(20) NOT NULL,
            title varchar(255) NOT NULL,
            import_date datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) DEFAULT 'completed',
            PRIMARY KEY (id),
            KEY tmdb_id (tmdb_id),
            KEY post_id (post_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

// Initialize the plugin
Enhanced_TMDB_Importer::get_instance();
