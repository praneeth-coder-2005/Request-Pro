# Enhanced TMDB Importer - Installation Guide

## Quick Start

### Step 1: Activate the Plugin
1. The plugin is already installed in your `wp-content/plugins/` directory
2. Go to **WordPress Admin > Plugins**
3. Find "Enhanced TMDB Importer" and click **Activate**

### Step 2: Configure TMDB API Key
1. Go to **TMDB Importer > Settings** in your WordPress admin
2. Get a free API key from [The Movie Database](https://www.themoviedb.org/account/signup):
   - Create an account at themoviedb.org
   - Go to Account Settings > API
   - Request an API key
   - Fill out the application form
3. Copy your API key and paste it in the settings
4. Click **Test TMDB Connection** to verify it works
5. Save settings

### Step 3: Start Importing
1. Go to **TMDB Importer > Search & Import**
2. Search for a movie or TV show
3. Click **Import** on any result
4. The content will be added to your Movies or TV Shows section

## Features Overview

### 🔍 Search & Import
- **Location**: TMDB Importer > Search & Import
- **Function**: Search TMDB and import individual items
- **Best for**: Adding specific movies/shows

### 📦 Bulk Import
- **Location**: TMDB Importer > Bulk Import
- **Function**: Import multiple items at once
- **Best for**: Adding many items quickly
- **Format**: Enter TMDB IDs like `550,movie` or `1399,tv`

### 📊 Import History
- **Location**: TMDB Importer > Import History
- **Function**: View all imported items and statistics
- **Features**: Edit links, import stats, search history

### ⚙️ Settings
- **Location**: TMDB Importer > Settings
- **Function**: Configure API key and import behavior
- **Options**: Language, image handling, batch sizes

## How It Works

### Data Import Process
1. **Search**: Plugin searches TMDB API for your query
2. **Select**: Choose items from search results
3. **Import**: Plugin fetches complete data from TMDB
4. **Create**: WordPress post is created with all metadata
5. **Images**: Poster images are downloaded and set as featured images
6. **Taxonomies**: Genres, countries, years are automatically assigned

### Where Content Goes
- **Movies**: Added as regular WordPress posts (Movies section)
- **TV Shows**: Added as 'tv' custom post type (TV Shows section)
- **Metadata**: Stored using IDMuvi Core meta fields
- **Images**: Downloaded to WordPress media library

### Integration with Your Theme
The plugin is designed to work seamlessly with:
- **MuviPro Theme**: Full compatibility with all theme features
- **IDMuvi Core Plugin**: Uses existing meta fields and post types
- **Existing Content**: Won't interfere with current movies/shows

## Troubleshooting

### Common Issues

**Plugin won't activate**
- Make sure IDMuvi Core plugin is active first
- Check PHP version (requires 7.4+)

**API connection fails**
- Verify your TMDB API key is correct
- Check if your server can make external requests
- Try the "Test Connection" button in settings

**Import fails**
- Check server memory limits
- Reduce bulk import batch size
- Ensure uploads directory is writable

**Images not downloading**
- Check file permissions on uploads folder
- Verify server can download external files
- Enable "Auto Set Featured Image" in settings

### Getting Help
1. Check the plugin settings page for help documentation
2. Review the README.md file for detailed information
3. Check WordPress error logs for specific error messages
4. Contact your developer if issues persist

## Best Practices

### For Best Results
1. **Start Small**: Import a few items first to test
2. **Use Bulk Import**: For adding many items efficiently
3. **Check Duplicates**: Plugin prevents duplicates automatically
4. **Monitor Progress**: Watch bulk import progress bars
5. **Review Imports**: Check Import History regularly

### Recommended Settings
- **Language**: Set to your site's primary language
- **Featured Images**: Keep enabled for better theme integration
- **Genres**: Keep enabled to organize content
- **Batch Size**: Start with 5, increase if no timeout issues

### Content Organization
- Use WordPress categories for genres
- Years are automatically assigned to year taxonomy
- Countries are assigned to country taxonomy
- TV shows get network information

## Advanced Usage

### CSV Bulk Import
Create a CSV file with columns:
```
tmdb_id,type,title
550,movie,Fight Club
1399,tv,Game of Thrones
238,movie,The Godfather
```

### Manual TMDB ID Entry
Format for manual bulk import:
```
550,movie
1399,tv
238,movie
157336,tv
```

### Finding TMDB IDs
1. Go to themoviedb.org
2. Search for your movie/show
3. Look at the URL: `https://www.themoviedb.org/movie/550-fight-club`
4. The number (550) is the TMDB ID

## Support

This plugin is designed to work perfectly with your existing MuviPro theme and IDMuvi Core setup. All imported content will appear in your theme's movie and TV show sections automatically.

For technical support, contact your developer or theme provider.
