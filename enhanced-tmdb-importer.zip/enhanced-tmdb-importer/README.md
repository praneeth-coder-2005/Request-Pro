# Enhanced TMDB Importer - Simple & Clean

A simple, clean TMDB importer that imports movies and TV shows from The Movie Database (TMDB) with all the essential information - no complicated streaming features, just pure TMDB importing.

## ✅ **Features**

### **🎬 Movie & TV Show Import**
- **Search TMDB database** by title
- **Import complete metadata** (title, description, cast, crew, genres)
- **Auto-download posters** and set as featured images
- **Import additional images** (backdrops, logos)
- **Bulk import** multiple items at once

### **📊 Metadata Imported**
- **Basic Info**: Title, overview, release date, runtime
- **Cast & Crew**: Actors, directors, writers
- **Genres**: Automatically creates and assigns genre terms
- **Images**: Poster, backdrop, logos
- **Ratings**: TMDB ratings and vote counts
- **Keywords**: Optional keyword import

### **⚙️ Simple Settings**
- **TMDB API Key**: Your free API key
- **Language**: Default language for imports
- **Image Settings**: Auto-set featured images
- **Import Options**: Choose what to import (cast, genres, keywords)
- **Batch Size**: How many to import at once

## 📋 **Installation Instructions**

### **Step 1: Get TMDB API Key**
1. **Visit** [themoviedb.org](https://www.themoviedb.org/account/signup) and create account
2. **Go to Account Settings** → **API**
3. **Request API key** and fill out information
4. **Copy your API key**

### **Step 2: Install Plugin**
1. **Upload** the `enhanced-tmdb-importer` folder to `/wp-content/plugins/`
2. **Activate** the plugin through the 'Plugins' screen in WordPress
3. **Go to TMDB Importer > Settings**
4. **Paste your API key**
5. **Configure settings** and save

### **Step 3: Configure Settings**
1. **Go to TMDB Importer > Settings**
2. **Add your TMDB API key**
3. **Choose your settings:**
   - ✅ Auto set featured image
   - ✅ Import cast & crew
   - ✅ Import genres
   - ⚪ Import keywords (optional)
   - Batch size: 5 (recommended)
4. **Save settings**
5. **Test connection** to verify API key works

### **Step 4: Start Importing**
1. **Go to TMDB Importer > Search & Import**
2. **Search for movies or TV shows**
3. **Click "Import"** on items you want
4. **Or use bulk import** for multiple items

## 🎬 **How to Use**

### **Single Import**
1. **Search**: Type movie/TV show name
2. **Browse Results**: See TMDB search results with posters
3. **Import**: Click "Import" button
4. **Done**: Movie/TV show created with all metadata

### **Bulk Import**
1. **Search**: Find multiple items
2. **Select**: Check boxes for items you want
3. **Bulk Import**: Click "Import Selected"
4. **Wait**: All items imported automatically

### **What Gets Created**
- **Post Type**: Movie or TV show post
- **Title**: From TMDB
- **Content**: Overview/description
- **Featured Image**: Movie poster
- **Custom Fields**: All TMDB metadata
- **Genres**: Auto-assigned
- **Cast/Crew**: Saved as metadata

## ⚙️ **Settings Explained**

### **API Configuration**
- **TMDB API Key**: Required for all imports
- **Default Language**: Language for imported content (en-US, es-ES, etc.)

### **Import Options**
- **Auto Set Featured Image**: Downloads and sets movie poster as featured image
- **Import Cast & Crew**: Saves actor and crew information
- **Import Genres**: Creates and assigns genre terms
- **Import Keywords**: Optional keyword metadata
- **Batch Size**: How many items to process at once (1-20)

## 🔧 **Troubleshooting**

### **API Connection Failed**
- **Check API key**: Make sure it's correct
- **Test connection**: Use the test button in settings
- **Wait time**: New API keys may take a few minutes to activate

### **Import Errors**
- **Check post type**: Make sure "Movies" or "TV Shows" post types exist
- **Check permissions**: Make sure you can create posts
- **Try smaller batch**: Reduce batch size if timeouts occur

### **Missing Images**
- **Check image settings**: Make sure "Auto set featured image" is enabled
- **Server permissions**: Make sure WordPress can download images
- **Try manual**: Some images may need manual upload

### **Slow Imports**
- **Reduce batch size**: Try 1-3 instead of 5+
- **Server resources**: Large imports need good hosting
- **API limits**: TMDB has rate limits

## 💡 **Best Practices**

### **Before Importing**
- **Test with one item** first
- **Check all settings** are correct
- **Backup your site** before bulk imports

### **During Import**
- **Don't close browser** during bulk imports
- **Monitor progress** in the import interface
- **Check for errors** and retry if needed

### **After Import**
- **Review imported content** for accuracy
- **Add any missing information** manually
- **Set up categories/menus** as needed

## 📊 **What You Get**

### **For Movies:**
```
✅ Title, overview, release date
✅ Director, cast, crew
✅ Genres, runtime, ratings
✅ Poster and backdrop images
✅ TMDB ID for future reference
```

### **For TV Shows:**
```
✅ Title, overview, first air date
✅ Creator, cast, crew
✅ Genres, episode count, ratings
✅ Poster and backdrop images
✅ Season information
```

## 🎯 **Perfect For**

- **Movie review sites**
- **Entertainment blogs**
- **Film databases**
- **TV show catalogs**
- **Media libraries**

## 🚀 **Simple Workflow**

1. **Setup**: Add API key and configure settings
2. **Search**: Find movies/TV shows on TMDB
3. **Import**: One-click import with all metadata
4. **Publish**: Content ready with images and info
5. **Customize**: Add your own reviews, ratings, etc.

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- TMDB API key (free)
- IDMuvi Core plugin (for movie post types)

This is a clean, simple TMDB importer focused on doing one thing well - importing complete movie and TV show information from TMDB without any complicated features! 🎉

## Support

For support and updates, visit the plugin settings page or check the documentation.

---

**Version**: 1.0.0  
**Author**: Enhanced TMDB Importer  
**License**: GPL v2 or later
